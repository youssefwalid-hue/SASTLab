#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
audit-report.py — Audit + génération de rapports de vulnérabilités, application par application.

Pour chaque application du Banking DAST Benchmark Lab :
  1. (AUDIT)  recalcule les verdicts via analyze.py (sauf --no-analyze),
  2. (RAPPORT) lit evidence/APP-XX/results.json (verdict + verdict_reason = preuve de
     confirmation du pipeline) et le VULNERABILITY_GUIDE.md de l'app (chemin d'attaque +
     payloads, en FR et EN),
  3. écrit un rapport HTML autonome BILINGUE (bascule FR/EN) par application :
       evidence/APP-XX/rapport-APP-XX.html
     et un index : evidence/index-rapports.html

Chaque fiche de vulnérabilité contient : identifiant, titre, sévérité, CWE, OWASP, verdict,
la PREUVE de confirmation (évidence HTTP réelle consignée dans le pipeline), le CHEMIN
D'ATTAQUE / séquence d'exécution, les PAYLOADS, et la remédiation — en français et en anglais.

Usage :
  python3 audit-report.py                 # toutes les apps (lance analyze.py d'abord)
  python3 audit-report.py APP-07 APP-09   # seulement ces apps
  python3 audit-report.py --no-analyze     # ne relance pas analyze.py
  python3 audit-report.py --pdf            # tente aussi un PDF (si un moteur headless existe)

Environnement :
  BASE   = $AUDIT_BASE   ou ~/banking-dast-fullscan
  GUIDES = $AUDIT_GUIDES ou ~/banking-dast-benchmark-lab-v23/05-applications
"""
import os, re, sys, json, html, subprocess, datetime, shutil, glob

HOME   = os.path.expanduser("~")
BASE   = os.environ.get("AUDIT_BASE",   os.path.join(HOME, "banking-dast-fullscan"))
GUIDES = os.environ.get("AUDIT_GUIDES", os.path.join(HOME, "banking-dast-benchmark-lab-v23", "05-applications"))
EVID   = os.path.join(BASE, "evidence")

SEV_COLOR = {"Critical":"#7c1d1d","High":"#b42318","Medium":"#b54708","Low":"#475467","":"#475467"}
VERD = {
 "CONFIRME":     {"fr":"Confirmée","en":"Confirmed","c":"#067647","bg":"#ecfdf3"},
 "A_VERIFIER":   {"fr":"À vérifier","en":"To verify","c":"#b54708","bg":"#fffaeb"},
 "NON_CONFIRME": {"fr":"Non confirmée","en":"Not confirmed","c":"#b42318","bg":"#fef3f2"},
}
LBL = {
 "report":      {"fr":"Rapport de vulnérabilités","en":"Vulnerability report"},
 "subtitle":    {"fr":"Audit DAST — preuves, chemins d'attaque et payloads","en":"DAST audit — proofs, attack paths and payloads"},
 "generated":   {"fr":"Généré le","en":"Generated"},
 "stack":       {"fr":"Pile technique","en":"Tech stack"},
 "total":       {"fr":"Vulnérabilités","en":"Vulnerabilities"},
 "confirmed":   {"fr":"Confirmées","en":"Confirmed"},
 "toverify":    {"fr":"À vérifier","en":"To verify"},
 "notconf":     {"fr":"Non confirmées","en":"Not confirmed"},
 "coverage":    {"fr":"Couverture","en":"Coverage"},
 "proof":       {"fr":"Preuve de confirmation (évidence HTTP du pipeline)","en":"Confirmation proof (pipeline HTTP evidence)"},
 "attack":      {"fr":"Chemin d'attaque & exécution","en":"Attack path & execution"},
 "payloads":    {"fr":"Détails / payloads","en":"Details / payloads"},
 "nodetail":    {"fr":"Pas de détail d'exploitation dans le guide pour cette entrée.","en":"No exploitation detail in the guide for this entry."},
 "severity":    {"fr":"Sévérité","en":"Severity"},
 "legal":       {"fr":"Laboratoire à données 100 % fictives. Usage défensif / benchmark interne. Ne jamais fournir ce document aux scanners évalués.",
                 "en":"Lab with 100% fictitious data. Defensive / internal benchmark use. Never provide this document to the benchmarked scanners."},
 "tocfr":       {"fr":"Sommaire","en":"Contents"},
 "index_title": {"fr":"Rapports d'audit par application","en":"Per-application audit reports"},
}

def e(s): return html.escape(str(s if s is not None else ""))

# ---------- rendu markdown léger (bullets, numéros, gras, code inline, blocs ```), bilingue-neutre ----------
def md_to_html(md):
    if not md: return ""
    lines = md.replace("\r","").split("\n")
    out, i, n = [], 0, len(lines)
    def inline(t):
        t = e(t)
        t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
        t = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', t)
        return t
    while i < n:
        ln = lines[i]
        # bloc de code ```
        if ln.strip().startswith("```"):
            i += 1; buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i]); i += 1
            i += 1
            out.append("<pre><code>"+e("\n".join(buf))+"</code></pre>")
            continue
        # liste numérotée  (1. ...)
        m = re.match(r'^\s*\d+\.\s+(.*)', ln)
        if m:
            out.append("<ol>")
            while i < n:
                mm = re.match(r'^\s*\d+\.\s+(.*)', lines[i])
                if not mm: break
                out.append("<li>"+inline(mm.group(1))+"</li>"); i += 1
            out.append("</ol>"); continue
        # liste à puces (- ...)
        if re.match(r'^\s*[-*]\s+', ln):
            out.append("<ul>")
            while i < n and re.match(r'^\s*[-*]\s+', lines[i]):
                out.append("<li>"+inline(re.sub(r'^\s*[-*]\s+','',lines[i]))+"</li>"); i += 1
            out.append("</ul>"); continue
        # citation >
        if ln.strip().startswith(">"):
            out.append("<blockquote>"+inline(ln.strip().lstrip(">").strip())+"</blockquote>"); i += 1; continue
        if ln.strip()=="":
            i += 1; continue
        out.append("<p>"+inline(ln)+"</p>"); i += 1
    return "\n".join(out)

# ---------- parsing du guide : sections FR et EN par VID ----------
def parse_guide(appid):
    """Retourne {vid: {'fr':{'title','body'}, 'en':{'title','body'}}} à partir du VULNERABILITY_GUIDE.md."""
    path = os.path.join(GUIDES, appid, "VULNERABILITY_GUIDE.md")
    res = {}
    if not os.path.exists(path):
        return res
    txt = open(path, encoding="utf-8", errors="replace").read()
    # séparer FR / EN
    split = re.split(r'\n#\s*English version\s*\n', txt, maxsplit=1)
    parts = {"fr": split[0]}
    if len(split) > 1:
        parts["en"] = split[1]
    pat = re.compile(r'\n##\s+('+re.escape(appid.replace("-",""))+r'-V\d+)\s*[—-]\s*(.*)')
    for lang, body in parts.items():
        # découpe par section ## APPXXVnnn
        idx = [(m.start(), m.group(1), m.group(2).strip()) for m in pat.finditer(body)]
        for k,(start,vid,title) in enumerate(idx):
            end = idx[k+1][0] if k+1 < len(idx) else len(body)
            # couper à un éventuel '## Use cases' / '# ' suivant inclus par la borne
            sect = body[start:end]
            sect = re.sub(r'^\n##[^\n]*\n', '', sect, count=1)  # retire la ligne de titre
            res.setdefault(vid, {})[lang] = {"title": title, "body": sect.strip()}
    return res

# ---------- captures HTTP réelles (requête/réponse) ----------
def appid_from_vid(vid):
    m = re.match(r'(APP)(\d\d)-', vid or "")
    return f"APP-{m.group(2)}" if m else ""

def load_capture(vid):
    """Lit evidence/APP-XX/captures/<vid>.http si présent (produit par capture.sh)."""
    appid = appid_from_vid(vid)
    if not appid: return None
    p = os.path.join(EVID, appid, "captures", vid + ".http")
    if os.path.exists(p):
        try: return open(p, encoding="utf-8", errors="replace").read()
        except Exception: return None
    return None

# ---------- rendu d'une fiche de vulnérabilité (les 2 langues) ----------
def vuln_card(f, guide):
    vid = f["id"]
    v = f.get("verdict","")
    vinfo = VERD.get(v, {"fr":v,"en":v,"c":"#475467","bg":"#f2f4f7"})
    sev = f.get("severity","")
    sevc = SEV_COLOR.get(sev, "#475467")
    owasp = f.get("owasp_api") or f.get("owasp") or ""
    cwe = f.get("cwe","")
    reason = f.get("verdict_reason","")
    g = guide.get(vid, {})
    def lang_block(lang):
        gl = g.get(lang, {})
        title = gl.get("title") or f.get("title","")
        body = md_to_html(gl.get("body","")) or '<p class="muted">'+LBL["nodetail"][lang]+'</p>'
        proof_html = ""
        if reason:
            proof_html = (f'<div class="proof"><div class="proof-h">{LBL["proof"][lang]}</div>'
                          f'<pre><code>{e(reason)}</code></pre></div>')
        return (f'<div class="lang lang-{lang}">'
                f'<h3>{e(vid)} — {e(title)}</h3>'
                f'{proof_html}'
                f'<div class="attack-h">{LBL["attack"][lang]} · {LBL["payloads"][lang]}</div>'
                f'<div class="body">{body}</div>'
                f'</div>')
    badges = (f'<span class="badge" style="background:{vinfo["bg"]};color:{vinfo["c"]}">'
              f'<span class="lang lang-fr">{vinfo["fr"]}</span><span class="lang lang-en">{vinfo["en"]}</span></span>'
              f'<span class="badge" style="background:#fff;border:1px solid {sevc};color:{sevc}">{e(sev)}</span>')
    if cwe:   badges += f'<span class="badge gray">{e(cwe)}</span>'
    if owasp: badges += f'<span class="badge gray">{e(owasp)}</span>'
    cap = load_capture(vid)
    cap_html = ""
    if cap:
        cap_html = ('<div class="capture"><div class="capture-h">'
                    '<span class="lang lang-fr">Requête / Réponse HTTP (capture réelle)</span>'
                    '<span class="lang lang-en">HTTP request / response (real capture)</span></div>'
                    f'<pre class="cap"><code>{e(cap)}</code></pre></div>')
    return (f'<section class="vuln" id="{e(vid)}">'
            f'<div class="vhead"><div class="vid">{e(vid)}</div><div class="badges">{badges}</div></div>'
            f'{lang_block("fr")}{lang_block("en")}'
            f'{cap_html}'
            f'</section>')

# ---------- rendu du rapport d'une app ----------
def render_app(app, guide):
    appid = app["app"]
    pct = round(100*app["confirme"]/app["total"]) if app["total"] else 0
    tiles = ""
    for key, val, col in [("total", app["total"], "#1f2937"),
                          ("confirmed", app["confirme"], VERD["CONFIRME"]["c"]),
                          ("toverify", app["a_verifier"], VERD["A_VERIFIER"]["c"]),
                          ("notconf", app["non_confirme"], VERD["NON_CONFIRME"]["c"])]:
        tiles += (f'<div class="tile"><div class="n" style="color:{col}">{val}</div>'
                  f'<div class="l"><span class="lang lang-fr">{LBL[key]["fr"]}</span>'
                  f'<span class="lang lang-en">{LBL[key]["en"]}</span></div></div>')
    cards = "".join(vuln_card(f, guide) for f in app["findings"])
    # sommaire
    toc = ""
    for f in app["findings"]:
        vinfo = VERD.get(f.get("verdict",""), {"c":"#475467"})
        toc += (f'<a href="#{e(f["id"])}" class="toc-i"><span class="dot" style="background:{vinfo["c"]}"></span>'
                f'{e(f["id"])} <span class="toc-t">{e(f.get("title",""))}</span></a>')
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(appid)} {e(app.get('brand',''))} — {LBL['report']['fr']} / {LBL['report']['en']}</title>
<style>
:root{{--bg:#f8fafc;--card:#fff;--ink:#101828;--muted:#667085;--line:#e4e7ec;--accent:#0b5cad}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.6 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}}
.wrap{{max-width:980px;margin:0 auto;padding:24px 16px 80px}}
header.top{{background:linear-gradient(135deg,#0b5cad,#083e76);color:#fff;border-radius:16px;padding:22px 24px;margin-bottom:18px}}
header.top h1{{margin:0 0 4px;font-size:22px}}
header.top .sub{{opacity:.85;font-size:13px}}
.langbar{{position:sticky;top:0;z-index:5;display:flex;gap:8px;justify-content:flex-end;padding:8px 0;background:var(--bg)}}
.langbar button{{border:1px solid var(--line);background:#fff;border-radius:999px;padding:6px 14px;cursor:pointer;font-weight:600;color:var(--muted)}}
.langbar button.on{{background:var(--accent);color:#fff;border-color:var(--accent)}}
.tiles{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0}}
.tile{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;text-align:center}}
.tile .n{{font-size:26px;font-weight:700}} .tile .l{{font-size:12px;color:var(--muted)}}
.bar{{height:8px;background:#eef2f6;border-radius:999px;overflow:hidden;margin-top:4px}}
.bar span{{display:block;height:100%;background:{VERD['CONFIRME']['c']}}}
.meta{{display:flex;flex-wrap:wrap;gap:16px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 16px;font-size:13px;color:var(--muted)}}
.toc{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 16px;margin:14px 0;columns:2;column-gap:24px}}
.toc h2{{font-size:14px;margin:0 0 8px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}}
.toc-i{{display:block;text-decoration:none;color:var(--ink);padding:3px 0;font-size:13px;break-inside:avoid}}
.toc-i .dot{{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}}
.toc-t{{color:var(--muted)}}
.vuln{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin:14px 0}}
.vhead{{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:6px}}
.vid{{font-weight:700;font-family:ui-monospace,Menlo,Consolas,monospace;color:var(--accent)}}
.badges{{display:flex;gap:6px;flex-wrap:wrap}}
.badge{{font-size:12px;font-weight:600;border-radius:999px;padding:3px 10px}}
.badge.gray{{background:#f2f4f7;color:#475467}}
.vuln h3{{font-size:16px;margin:10px 0 8px}}
.attack-h{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);margin:14px 0 4px;border-top:1px dashed var(--line);padding-top:10px}}
.proof{{background:#ecfdf3;border:1px solid #abefc6;border-radius:10px;padding:10px 12px;margin:6px 0}}
.proof-h{{font-size:12px;font-weight:700;color:{VERD['CONFIRME']['c']};margin-bottom:4px}}
.capture{{margin:10px 0}}
.capture-h{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#0b5cad;font-weight:700;margin:8px 0 4px}}
pre.cap{{background:#0b1020;color:#cfe3ff;max-height:420px}}
.body ul,.body ol{{margin:6px 0 6px 2px;padding-left:20px}} .body li{{margin:2px 0}}
.body p{{margin:6px 0}}
code{{background:#f2f4f7;border-radius:5px;padding:1px 5px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;word-break:break-word}}
pre{{background:#0e1726;color:#e6edf3;border-radius:10px;padding:12px 14px;overflow:auto;font-size:12.5px;line-height:1.5}}
pre code{{background:none;color:inherit;padding:0}}
blockquote{{border-left:3px solid var(--line);margin:6px 0;padding:2px 12px;color:var(--muted)}}
.muted{{color:var(--muted)}}
footer{{margin-top:22px;font-size:12px;color:var(--muted);text-align:center}}
.lang-en{{display:none}}
body.en .lang-fr{{display:none}} body.en .lang-en{{display:inline}}
body.en .body .lang-en,body.en .proof .lang-en{{display:block}}
@media (max-width:640px){{.tiles{{grid-template-columns:repeat(2,1fr)}} .toc{{columns:1}}}}
@media print{{.langbar{{display:none}} body{{background:#fff}} .vuln,.tile,.meta,.toc{{break-inside:avoid}}}}
</style></head>
<body>
<div class="langbar"><button id="bfr" class="on" onclick="setLang('fr')">Français</button>
<button id="ben" onclick="setLang('en')">English</button></div>
<div class="wrap">
<header class="top">
  <h1>{e(appid)} — {e(app.get('brand',''))}</h1>
  <div class="sub"><span class="lang lang-fr">{LBL['report']['fr']} · {LBL['subtitle']['fr']}</span>
  <span class="lang lang-en">{LBL['report']['en']} · {LBL['subtitle']['en']}</span></div>
</header>
<div class="meta">
  <div><strong><span class="lang lang-fr">{LBL['stack']['fr']}</span><span class="lang lang-en">{LBL['stack']['en']}</span> :</strong> {e(app.get('stack',''))}</div>
  <div><strong><span class="lang lang-fr">{LBL['generated']['fr']}</span><span class="lang lang-en">{LBL['generated']['en']}</span> :</strong> {now}</div>
  <div style="flex:1;min-width:160px"><span class="lang lang-fr">{LBL['coverage']['fr']}</span><span class="lang lang-en">{LBL['coverage']['en']}</span> : <strong>{app['confirme']}/{app['total']}</strong> ({pct}%)<div class="bar"><span style="width:{pct}%"></span></div></div>
</div>
<div class="tiles">{tiles}</div>
<div class="toc"><h2><span class="lang lang-fr">{LBL['tocfr']['fr']}</span><span class="lang lang-en">{LBL['tocfr']['en']}</span></h2>{toc}</div>
{cards}
<footer><span class="lang lang-fr">{LBL['legal']['fr']}</span><span class="lang lang-en">{LBL['legal']['en']}</span></footer>
</div>
<script>
function setLang(l){{document.body.classList.toggle('en',l==='en');
document.getElementById('bfr').classList.toggle('on',l==='fr');
document.getElementById('ben').classList.toggle('on',l==='en');
try{{localStorage.setItem('auditLang',l)}}catch(e){{}}}}
try{{var s=localStorage.getItem('auditLang');if(s)setLang(s)}}catch(e){{}}
</script>
</body></html>"""

def render_index(apps):
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    tot = sum(a["total"] for a in apps); conf = sum(a["confirme"] for a in apps)
    rows = ""
    for a in apps:
        pct = round(100*a["confirme"]/a["total"]) if a["total"] else 0
        rows += (f'<tr><td><a href="APP-{a["app"].split("-")[1]}/rapport-{a["app"]}.html">{e(a["app"])} {e(a.get("brand",""))}</a></td>'
                 f'<td>{e(a.get("stack",""))}</td><td>{a["total"]}</td>'
                 f'<td style="color:{VERD["CONFIRME"]["c"]};font-weight:600">{a["confirme"]}</td>'
                 f'<td>{a["a_verifier"]}</td><td>{a["non_confirme"]}</td>'
                 f'<td><div class="bar"><span style="width:{pct}%"></span></div>{pct}%</td></tr>')
    return f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{LBL['index_title']['fr']} / {LBL['index_title']['en']}</title>
<style>body{{font:15px/1.6 -apple-system,Segoe UI,Roboto,Arial,sans-serif;max-width:960px;margin:0 auto;padding:30px 16px;color:#101828;background:#f8fafc}}
h1{{font-size:22px}} .sub{{color:#667085;margin-bottom:18px}}
table{{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e4e7ec;border-radius:12px;overflow:hidden}}
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eef2f6;font-size:14px}} th{{background:#f2f4f7;font-size:12px;text-transform:uppercase;color:#475467}}
a{{color:#0b5cad;text-decoration:none;font-weight:600}}
.bar{{height:8px;width:90px;background:#eef2f6;border-radius:999px;overflow:hidden;display:inline-block;vertical-align:middle;margin-right:6px}}
.bar span{{display:block;height:100%;background:{VERD['CONFIRME']['c']}}}
.big{{font-size:28px;font-weight:700;color:{VERD['CONFIRME']['c']}}}</style></head>
<body><h1>{LBL['index_title']['fr']}<br><span style="font-size:15px;color:#667085">{LBL['index_title']['en']}</span></h1>
<div class="sub">{LBL['generated']['fr']} / {LBL['generated']['en']} : {now} — <span class="big">{conf}/{tot}</span> ({round(100*conf/tot)}%)</div>
<table><thead><tr><th>App</th><th>Stack</th><th>Total</th><th>{LBL['confirmed']['fr']}</th><th>{LBL['toverify']['fr']}</th><th>{LBL['notconf']['fr']}</th><th>{LBL['coverage']['fr']}</th></tr></thead>
<tbody>{rows}</tbody></table></body></html>"""

SURFACE = {"APP-01":{"fr":"Web + API REST","en":"Web + REST API"},
 "APP-02":{"fr":"API REST (OpenAPI) + JWT/OAuth2","en":"REST API (OpenAPI) + JWT/OAuth2"},
 "APP-03":{"fr":"SPA + API REST (Bearer)","en":"SPA + REST API (Bearer)"},
 "APP-04":{"fr":"Web + API (PHP)","en":"Web + API (PHP)"},
 "APP-05":{"fr":"Web (session, CSRF)","en":"Web (session, CSRF)"},
 "APP-06":{"fr":"API GraphQL","en":"GraphQL API"},
 "APP-07":{"fr":"API SOAP/XML (WSDL)","en":"SOAP/XML API (WSDL)"},
 "APP-08":{"fr":"Web + API REST JSON","en":"Web + REST JSON API"},
 "APP-09":{"fr":"SPA + API REST (OIDC PKCE)","en":"SPA + REST API (OIDC PKCE)"},
 "APP-10":{"fr":"REST + reverse proxy (microservices)","en":"REST + reverse proxy (microservices)"}}

def render_description(apps):
    """Document descriptif du lab : vue d'ensemble + fiche par application + table des vulnérabilités."""
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    tot = sum(a["total"] for a in apps); conf = sum(a["confirme"] for a in apps)
    # vue d'ensemble
    ov = ('<table><thead><tr><th>App</th>'
          '<th><span class="lang lang-fr">Marque</span><span class="lang lang-en">Brand</span></th>'
          '<th>Stack</th><th><span class="lang lang-fr">Surface</span><span class="lang lang-en">Surface</span></th>'
          '<th><span class="lang lang-fr">Vulns</span><span class="lang lang-en">Vulns</span></th>'
          '<th><span class="lang lang-fr">Confirmées</span><span class="lang lang-en">Confirmed</span></th></tr></thead><tbody>')
    for a in apps:
        s = SURFACE.get(a["app"], {"fr":"","en":""})
        ov += (f'<tr><td class="mono"><a href="#{e(a["app"])}">{e(a["app"])}</a></td><td>{e(a.get("brand",""))}</td>'
               f'<td>{e(a.get("stack",""))}</td>'
               f'<td><span class="lang lang-fr">{s["fr"]}</span><span class="lang lang-en">{s["en"]}</span></td>'
               f'<td>{a["total"]}</td><td style="color:{VERD["CONFIRME"]["c"]};font-weight:600">{a["confirme"]}/{a["total"]}</td></tr>')
    ov += "</tbody></table>"
    # sections par app
    secs = ""
    for a in apps:
        appid = a["app"]; s = SURFACE.get(appid, {"fr":"","en":""})
        rows = ""
        for f in a["findings"]:
            vinfo = VERD.get(f.get("verdict",""), {"fr":f.get("verdict",""),"en":f.get("verdict",""),"c":"#475467"})
            reason = e(f.get("verdict_reason",""))
            rows += (f'<tr><td class="mono">{e(f["id"])}</td><td>{e(f.get("title",""))}</td>'
                     f'<td>{e(f.get("cwe",""))}</td><td>{e(f.get("severity",""))}</td>'
                     f'<td style="color:{vinfo["c"]};font-weight:600"><span class="lang lang-fr">{vinfo["fr"]}</span><span class="lang lang-en">{vinfo["en"]}</span></td>'
                     f'<td class="reason">{reason}</td></tr>')
        pct = round(100*a["confirme"]/a["total"]) if a["total"] else 0
        secs += (f'<section class="appsec" id="{e(appid)}"><h2>{e(appid)} — {e(a.get("brand",""))}</h2>'
                 f'<div class="appmeta"><strong>Stack :</strong> {e(a.get("stack",""))} · '
                 f'<strong><span class="lang lang-fr">Surface</span><span class="lang lang-en">Surface</span> :</strong> '
                 f'<span class="lang lang-fr">{s["fr"]}</span><span class="lang lang-en">{s["en"]}</span> · '
                 f'<strong><span class="lang lang-fr">Couverture</span><span class="lang lang-en">Coverage</span> :</strong> {a["confirme"]}/{a["total"]} ({pct}%)</div>'
                 '<table class="vt"><thead><tr><th>ID</th>'
                 '<th><span class="lang lang-fr">Vulnérabilité</span><span class="lang lang-en">Vulnerability</span></th>'
                 '<th>CWE</th><th><span class="lang lang-fr">Sév.</span><span class="lang lang-en">Sev.</span></th>'
                 '<th><span class="lang lang-fr">Verdict</span><span class="lang lang-en">Verdict</span></th>'
                 '<th><span class="lang lang-fr">Preuve (résumé)</span><span class="lang lang-en">Evidence (summary)</span></th></tr></thead>'
                 f'<tbody>{rows}</tbody></table>'
                 f'<p class="morelink"><a href="{e(appid)}/rapport-{e(appid)}.html">'
                 '<span class="lang lang-fr">→ Rapport détaillé (chemin d\'attaque, payloads, requêtes/réponses)</span>'
                 '<span class="lang lang-en">→ Detailed report (attack path, payloads, requests/responses)</span></a></p></section>')
    intro_fr = ("Laboratoire interne de <strong>benchmarking de scanners DAST</strong> : 10 applications bancaires "
      "<strong>volontairement vulnérables</strong>, à données 100 % fictives, sur des piles techniques variées "
      "(Spring Boot, NestJS, .NET, Symfony, Django, Go/GraphQL, WCF/SOAP, Rails, FastAPI, microservices Docker). "
      "Elles portent un corpus maîtrisé de <strong>219 vulnérabilités</strong> + 127 contrôles négatifs, avec un "
      "oracle de vérité <strong>confirmé à "+str(conf)+"/"+str(tot)+"</strong> par preuve HTTP réelle. Ce document "
      "décrit le lab, chaque application et ses vulnérabilités.")
    intro_en = ("Internal <strong>DAST scanner benchmarking</strong> lab: 10 <strong>deliberately vulnerable</strong> "
      "banking applications, 100% fictitious data, across varied stacks (Spring Boot, NestJS, .NET, Symfony, Django, "
      "Go/GraphQL, WCF/SOAP, Rails, FastAPI, Docker microservices). They carry a controlled corpus of "
      "<strong>219 vulnerabilities</strong> + 127 negative controls, with a ground-truth oracle "
      "<strong>confirmed at "+str(conf)+"/"+str(tot)+"</strong> by real HTTP evidence. This document describes the lab, "
      "each application and its vulnerabilities.")
    return f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Lab DAST — Description / Description</title>
<style>
:root{{--bg:#f8fafc;--card:#fff;--ink:#101828;--muted:#667085;--line:#e4e7ec;--accent:#0b5cad}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.6 -apple-system,Segoe UI,Roboto,Arial,sans-serif}}
.wrap{{max-width:1040px;margin:0 auto;padding:24px 16px 80px}}
header.top{{background:linear-gradient(135deg,#0b5cad,#083e76);color:#fff;border-radius:16px;padding:22px 24px;margin-bottom:16px}}
header.top h1{{margin:0 0 6px;font-size:23px}}
.langbar{{position:sticky;top:0;z-index:5;display:flex;gap:8px;justify-content:flex-end;padding:8px 0;background:var(--bg)}}
.langbar button{{border:1px solid var(--line);background:#fff;border-radius:999px;padding:6px 14px;cursor:pointer;font-weight:600;color:var(--muted)}}
.langbar button.on{{background:var(--accent);color:#fff;border-color:var(--accent)}}
table{{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden;margin:12px 0}}
th,td{{padding:8px 10px;text-align:left;border-bottom:1px solid #eef2f6;font-size:13.5px;vertical-align:top}}
th{{background:#f2f4f7;font-size:11.5px;text-transform:uppercase;color:#475467}}
.mono{{font-family:ui-monospace,Menlo,Consolas,monospace}} a{{color:var(--accent);text-decoration:none;font-weight:600}}
.appsec{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px 18px;margin:16px 0}}
.appsec h2{{margin:0 0 6px;font-size:18px;color:var(--accent)}}
.appmeta{{color:var(--muted);font-size:13px;margin-bottom:6px}}
.reason{{color:#475467;font-size:12.5px}} .vt td{{font-size:12.5px}}
.morelink{{margin:8px 0 0}} .intro{{font-size:15px}}
.lang-en{{display:none}} body.en .lang-fr{{display:none}} body.en .lang-en{{display:inline}}
@media print{{.langbar{{display:none}} .appsec,table{{break-inside:avoid}}}}
</style></head><body>
<div class="langbar"><button id="bfr" class="on" onclick="setLang('fr')">Français</button>
<button id="ben" onclick="setLang('en')">English</button></div>
<div class="wrap">
<header class="top"><h1><span class="lang lang-fr">Banking DAST Benchmark Lab — Description du laboratoire</span>
<span class="lang lang-en">Banking DAST Benchmark Lab — Lab description</span></h1>
<div style="opacity:.85;font-size:13px">{now} · {conf}/{tot} <span class="lang lang-fr">confirmées</span><span class="lang lang-en">confirmed</span></div></header>
<p class="intro"><span class="lang lang-fr">{intro_fr}</span><span class="lang lang-en">{intro_en}</span></p>
<h2><span class="lang lang-fr">Vue d'ensemble</span><span class="lang lang-en">Overview</span></h2>
{ov}
<h2><span class="lang lang-fr">Applications et vulnérabilités</span><span class="lang lang-en">Applications and vulnerabilities</span></h2>
{secs}
<footer style="margin-top:20px;color:var(--muted);font-size:12px;text-align:center">
<span class="lang lang-fr">Données 100 % fictives · usage défensif · oracle jamais fourni aux scanners évalués.</span>
<span class="lang lang-en">100% fictitious data · defensive use · oracle never provided to evaluated scanners.</span></footer>
</div>
<script>function setLang(l){{document.body.classList.toggle('en',l==='en');
document.getElementById('bfr').classList.toggle('on',l==='fr');document.getElementById('ben').classList.toggle('on',l==='en');
try{{localStorage.setItem('auditLang',l)}}catch(e){{}}}}
try{{var s=localStorage.getItem('auditLang');if(s)setLang(s)}}catch(e){{}}</script>
</body></html>"""

def try_pdf(html_path):
    pdf_path = html_path[:-5] + ".pdf"
    for exe in ("chromium","chromium-browser","google-chrome","google-chrome-stable"):
        if shutil.which(exe):
            try:
                subprocess.run([exe,"--headless","--no-sandbox","--disable-gpu",
                                f"--print-to-pdf={pdf_path}", "file://"+os.path.abspath(html_path)],
                               check=True, capture_output=True, timeout=120)
                if os.path.exists(pdf_path): return pdf_path
            except Exception: pass
    return None

def main():
    args = [a for a in sys.argv[1:]]
    do_analyze = "--no-analyze" not in args
    want_pdf   = "--pdf" in args
    only = [a.upper() for a in args if re.match(r'APP-?\d+', a, re.I)]
    only = [a if a.startswith("APP-") else a.replace("APP","APP-") for a in only]

    if do_analyze:
        print("[audit] analyze.py…")
        r = subprocess.run([sys.executable, os.path.join(BASE,"analyze.py")], cwd=BASE,
                           capture_output=True, text=True)
        print("        " + (r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "ok"))

    cj = os.path.join(EVID, "consolidated.json")
    if not os.path.exists(cj):
        print("ERREUR: "+cj+" introuvable. Lancez analyze.py d'abord."); sys.exit(1)
    cons = json.load(open(cj, encoding="utf-8"))
    apps = cons["apps"]

    describe_only = "--describe" in args and not only   # --describe seul = juste la description
    # charger les findings détaillés (verdict_reason) pour TOUTES les apps
    for app in apps:
        rp = os.path.join(EVID, app["app"], "results.json")
        if os.path.exists(rp):
            app["findings"] = json.load(open(rp, encoding="utf-8"))["findings"]

    produced = []
    if not describe_only:
        for app in apps:
            appid = app["app"]
            if only and appid not in only: continue
            guide = parse_guide(appid)
            out = os.path.join(EVID, appid, f"rapport-{appid}.html")
            open(out, "w", encoding="utf-8").write(render_app(app, guide))
            msg = f"[rapport] {appid}: {app['confirme']}/{app['total']} -> {out}"
            if want_pdf:
                p = try_pdf(out); msg += (f"  (+PDF {os.path.basename(p)})" if p else "  (PDF: aucun moteur headless)")
            print(msg); produced.append(appid)
        idx = os.path.join(EVID, "index-rapports.html")
        open(idx, "w", encoding="utf-8").write(render_index(apps))
        print(f"[index]   {idx}")

    # document descriptif du lab : toujours sur l'ensemble des apps
    desc = os.path.join(EVID, "LAB_DESCRIPTION.html")
    open(desc, "w", encoding="utf-8").write(render_description(apps))
    print(f"[lab]     {desc}")
    if want_pdf:
        p = try_pdf(desc); print("          "+(f"(+PDF {os.path.basename(p)})" if p else "(PDF: aucun moteur headless)"))

    print(f"\nTerminé : {len(produced)} rapport(s) + description du lab.")

if __name__ == "__main__":
    main()
