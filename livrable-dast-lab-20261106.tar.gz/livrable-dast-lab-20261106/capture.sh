#!/bin/bash
# capture.sh — enregistre la REQUÊTE et la RÉPONSE HTTP réelles d'une preuve de vulnérabilité,
# pour enrichir les rapports (audit-report.py v2 les intègre automatiquement).
#
# Usage :
#   bash capture.sh APP-XX APPxx-Vnnn -- <arguments curl…>
# Exemple :
#   bash capture.sh APP-02 APP02-V009 -- -X POST https://app02.lab.zt3c-consulting.com/v1/consents \
#        -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
#        --data '{"user":"alice","permissions":["accounts:read"],"callbackUrl":"http://127.0.0.1:5000/"}'
#
# Sortie : evidence/APP-XX/captures/APPxx-Vnnn.http  (bloc REQUÊTE + bloc RÉPONSE)
set -euo pipefail
BASE="${AUDIT_BASE:-$HOME/banking-dast-fullscan}"
APP="${1:?usage: capture.sh APP-XX VID -- <curl args>}"
VID="${2:?usage: capture.sh APP-XX VID -- <curl args>}"
shift 2; [ "${1:-}" = "--" ] && shift
DIR="$BASE/evidence/$APP/captures"; mkdir -p "$DIR"
OUT="$DIR/$VID.http"
TRACE="$(mktemp)"

# -s silent, -k self-signed, -i inclut les en-têtes de réponse, --trace-ascii capture la requête émise
RESP="$(curl -sS -k -i --trace-ascii "$TRACE" "$@" 2>/dev/null || true)"

{
  echo "# $VID — capture $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo
  echo "===== REQUÊTE / REQUEST ====="
  # reconstruit la requête HTTP (en-têtes + corps) depuis le trace curl
  awk '
    /^=> Send (header|data)/ {cap=1; next}
    /^=>|^<=|^== Info|^\{ \[|^\} \[/ {cap=0}
    cap && /^[0-9a-f]{4}: / { line=$0; sub(/^[0-9a-f]{4}: /,"",line); printf "%s", line "\n" }
  ' "$TRACE" | sed 's/[[:space:]]*$//'
  echo
  echo "# Commande reproductible :"
  printf '# curl -sk -i'; for a in "$@"; do printf " %q" "$a"; done; printf '\n'
  echo
  echo "===== RÉPONSE / RESPONSE ====="
  printf '%s\n' "$RESP"
} > "$OUT"
rm -f "$TRACE"
echo "capture -> $OUT  ($(wc -l < "$OUT") lignes)"
