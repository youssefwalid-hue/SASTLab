#!/usr/bin/env python3
# verify_captures.py — contrôle qualité des preuves (captures .http) du Banking DAST Benchmark Lab.
# Pour chaque vulnérabilité CONFIRME de l'oracle, lit evidence/APP-XX/captures/<VID>.http et vérifie
# que la RÉPONSE prouve réellement l'exploit (pas seulement qu'un fichier existe). Classe en OK / SUSPECT / REVIEW.
#
# N'interroge PAS le lab : analyse uniquement les captures déjà écrites (par replay.sh).
# Usage : python3 verify_captures.py            (dans ~/banking-dast-fullscan)
#         python3 verify_captures.py --all      (affiche aussi les OK)
import json, glob, os, re, sys

BASE = os.environ.get("AUDIT_BASE", ".")
SHOW_ALL = "--all" in sys.argv

def load():
    return json.load(open(os.path.join(BASE, "evidence", "consolidated.json"), encoding="utf-8"))

def vof(s):
    m = re.search(r'V\d+', s); return m.group(0) if m else None

def cap_path(app, vid):
    # fichiers nommés APP01-V007.http
    p = os.path.join(BASE, "evidence", app, "captures", vid + ".http")
    if os.path.exists(p): return p
    # tolère APP1-V007 / variations
    g = glob.glob(os.path.join(BASE, "evidence", app, "captures", "*%s.http" % vof(vid)))
    return g[0] if g else None

def parse(path):
    """Retourne (statuses[list int], resp_headers[dict premier bloc réponse], body_concat[str], raw[str])."""
    raw = open(path, encoding="utf-8", errors="ignore").read()
    statuses = [int(m) for m in re.findall(r'(?mi)^HTTP/\d(?:\.\d)?\s+(\d{3})', raw)]
    # premier bloc de réponse : en-têtes jusqu'à ligne vide
    headers = {}
    mh = re.search(r'(?mis)^HTTP/\d(?:\.\d)?\s+\d{3}[^\n]*\n(.*?)\r?\n\r?\n', raw)
    if mh:
        for line in mh.group(1).splitlines():
            if ':' in line:
                k, v = line.split(':', 1); headers[k.strip().lower()] = v.strip()
    # corps = tout ce qui suit les lignes d'en-tête de réponse (approché : concatène tout le texte après chaque bloc d'en-têtes)
    body = raw
    return statuses, headers, body, raw

def has_hdr(h, name): return name.lower() in h
def any_kw(s, kws): return any(k.lower() in s.lower() for k in kws)

def classify(fid, title, kind, statuses, headers, body, raw):
    t = (title or "") + " " + (kind or "")
    tl = t.lower()
    first = statuses[0] if statuses else None
    ok = ("OK", "")
    def sus(msg): return ("SUSPECT", msg)
    def rev(msg): return ("REVIEW", msg)

    if not statuses:
        return sus("aucune réponse HTTP dans la capture")

    # --- en-têtes ABSENTS attendus (durcissement) ---
    if any_kw(tl, ["hsts", "strict-transport"]):
        return ok if not has_hdr(headers, "strict-transport-security") else sus("HSTS présent (attendu absent)")
    if any_kw(tl, ["x-frame", "clickjacking"]):
        return ok if not has_hdr(headers, "x-frame-options") else sus("X-Frame-Options présent")
    if any_kw(tl, ["nosniff", "x-content-type"]):
        return ok if not has_hdr(headers, "x-content-type-options") else sus("nosniff présent")
    if any_kw(tl, ["en-têtes de sécurité", "en-tetes de securite", "csp", "durcissement", "security header", "header absent"]):
        present = [x for x in ("content-security-policy", "x-frame-options", "strict-transport-security") if has_hdr(headers, x)]
        return ok if not present else rev("certains en-têtes présents: " + ",".join(present))
    # cookies
    if "cookie" in tl or "httponly" in tl or "samesite" in tl:
        sc = headers.get("set-cookie", "")
        if not sc and not any("set-cookie" in l.lower() for l in raw.splitlines()):
            return rev("pas de Set-Cookie dans le 1er bloc (voir capture)")
        scall = " ".join(l for l in raw.splitlines() if l.lower().startswith("set-cookie"))
        return ok  # présence du cookie ; le détail des flags est dans la capture

    # --- divulgation / exposition (attendu: 200 + signal) ---
    if any_kw(tl, ["bannière", "banniere", "version", "x-powered"]):
        return ok if (has_hdr(headers, "server") or has_hdr(headers, "x-powered-by")) else sus("ni Server ni X-Powered-By")
    if any_kw(tl, ["verbeux", "verbose", "erreur", "stack", "trace", "209", "debug"]):
        if first in (500, 404) or any_kw(raw, ["exception", "traceback", "stack", "at ", "ActionController", "System.", "NestJS", "RoutingError", "Werkzeug", "DEBUG"]):
            return ok
        return rev("pas de motif d'erreur détaillée évident")
    if any_kw(tl, ["actuator", "profiler", "swagger", "/docs", "openapi", "rails/info", "wsdl", "introspection", "__schema", "directory", "listing", "répertoire", "repertoire"]):
        if first in (200, 201): return ok
        return sus("statut %s (attendu 200)" % first)

    # --- redirections ---
    if any_kw(tl, ["redirect", "redirection", "open redirect"]):
        loc = headers.get("location", "")
        if first in (301, 302, 303, 307, 308) and any_kw(loc, ["attaquant", "evil", "phish", "exemple"]):
            return ok
        return sus("pas de 30x vers domaine externe (statut %s, loc=%s)" % (first, loc[:40]))

    # --- XSS réfléchi : payload présent non échappé ---
    if "réfléchi" in tl or "reflechi" in tl or "reflected" in tl:
        if any_kw(raw, ["<script", "<svg", "onerror=", "<img src=x"]):
            return ok
        return sus("payload non retrouvé en clair dans la réponse (peut être échappé)")
    if "stocké" in tl or "stocke" in tl or "stored" in tl:
        if first in (200, 201, 302): return ok
        return sus("écriture non acceptée (statut %s)" % first)

    # --- SSTI / évaluation d'expression ---
    if any_kw(tl, ["ssti", "spel", "template", "expression", "eval"]):
        if any_kw(raw, ["361", "49", "31330", "command", "uid=", "root:"]):
            return ok
        return rev("résultat évalué (361/49/…) non détecté — vérifier la réponse")

    # --- injection commande OS ---
    if any_kw(tl, ["commande os", "command", "os command", "diagnosticping", "cwe-78"]):
        return ok if any_kw(raw, ["uid=", "gid=", "root:"]) else rev("sortie de commande non détectée")

    # --- traversée / LFI ---
    if any_kw(tl, ["traversée", "traversee", "lfi", "path traversal", "chemin", "cwe-22"]):
        if any_kw(raw, ["root:x:", "[extensions]", "[fonts]", "daemon:", "/bin/bash"]):
            return ok
        return rev("contenu de fichier hors périmètre non détecté")

    # --- énumération de comptes : deux réponses distinctes ---
    if any_kw(tl, ["énumération", "enumeration", "account-check", "reset", "forgot", "recover", "cwe-204"]):
        if len(statuses) >= 2 and statuses[0] != statuses[1]:
            return ok
        if any_kw(raw, ["aucun compte", "n'existe", "introuvable", "no account", "not found", "envoyé", "envoye", "sent"]):
            return ok
        return rev("distinction existant/inexistant non évidente (statuts=%s)" % statuses[:3])

    # --- race condition ---
    if any_kw(tl, ["race", "toctou", "cwe-362"]):
        n201 = len(re.findall(r'(?m)^201$', raw)) + raw.count("201 Created")
        return ok if n201 >= 2 else sus("une seule acceptation détectée (race non prouvée)")

    # --- CORS ---
    if "cors" in tl or "cwe-942" in tl:
        acao = headers.get("access-control-allow-origin", "")
        if acao == "*" or any_kw(acao, ["attaquant", "evil", "exemple"]):
            return ok
        if any_kw(raw, ["access-control-allow-origin"]):
            return rev("ACAO présent mais non reflété (%s)" % acao[:30])
        return sus("pas d'en-tête ACAO")

    # --- JWT (alg:none, confusion, aud, exp, signature) ---
    if "jwt" in tl or "alg" in tl or "signature" in tl or "aud" in tl or any_kw(tl, ["confusion", "cwe-347", "cwe-287", "cwe-613"]):
        return ok if first in (200, 201) else sus("statut %s (attendu 200 — token forgé accepté)" % first)

    # --- WebDAV / méthodes HTTP ---
    if any_kw(tl, ["webdav", "méthodes http", "methodes http", "méthodes d'écriture", "methodes d'ecriture", "trace", "cwe-650"]):
        allow = headers.get("allow", "")
        if any_kw(allow, ["PUT", "DELETE", "PROPFIND", "TRACE", "PATCH"]): return ok
        if first in (200, 204): return rev("OPTIONS %s — vérifier le verbe dangereux dans Allow (%s)" % (first, allow[:40]))
        return rev("Allow sans verbe dangereux (%s)" % allow[:40])

    # --- XXE / expansion entités ---
    if "xxe" in tl or "entité" in tl or "entites" in tl or "billion" in tl or "expansion" in tl:
        return rev("XXE/DoS — vérifier canary/hostname ou 500 dans la capture")

    # --- CRLF / header injection ---
    if "crlf" in tl or "cwe-93" in tl or ("en-tête" in tl and "injection" in tl):
        return ok if "set-cookie: x=1" in raw.lower() else rev("en-tête injecté non reflété")

    # --- bypass / contrôle d'accès / mass-assign / BFLA / BOLA / IDOR / logique métier ---
    if any_kw(tl, ["idor", "bola", "bfla", "mass assignment", "over-post", "strong params", "élévation", "elevation",
                   "propriété", "propriete", "contournement", "bypass", "auto-approbation", "double validation",
                   "négatif", "negatif", "plafond", "délai", "delai", "statut", "status", "scope", "rôle", "role",
                   "exposition", "excessive", "pan", "cvv", "auth manquante", "sans auth", "cwe-306", "cwe-639",
                   "cwe-285", "cwe-915", "cwe-840", "cwe-213", "cwe-269", "cwe-862"]):
        if first in (200, 201, 302): return ok
        return sus("statut %s (attendu 200/201/302 — action aboutie)" % first)

    # --- SQLi ---
    if "sql" in tl or kind == "sqli" or "cwe-89" in tl:
        if first in (200, 500): return rev("SQLi — vérifier le différentiel vrai/faux dans la capture (statut %s)" % first)
        return sus("statut %s inattendu" % first)

    # --- SSRF ---
    if "ssrf" in tl or "cwe-918" in tl:
        return rev("SSRF — vérifier dans la capture que l'URL interne a bien été requêtée côté serveur")

    # --- upload non restreint ---
    if any_kw(tl, ["upload", "cwe-434", "téléversement", "televersement"]):
        return ok if first in (200, 201, 302) else sus("upload non accepté (statut %s)" % first)

    # --- désérialisation / fixation / rate-limit / divers ---
    if any_kw(tl, ["désérialisation", "deserialisation", "pickle", "$type", "viewstate", "cwe-502"]):
        return rev("désérialisation — vérifier l'effet dans la capture (statut %s)" % first)
    if "fixation" in tl:
        return rev("fixation de session — vérifier que l'id n'est pas régénéré")
    if any_kw(tl, ["rate-limit", "rate limit", "brute", "cwe-770", "cwe-307"]):
        return rev("rate-limit/brute — nature répétitive, vérifier absence de throttling")

    # défaut
    if first in (200, 201, 302): return rev("règle générique: statut %s plausible — vérifier" % first)
    return sus("statut %s sans règle spécifique" % first)

def main():
    d = load()
    tot = {"OK": 0, "SUSPECT": 0, "REVIEW": 0, "MANQUANT": 0}
    suspects = []; reviews = []
    for a in d["apps"]:
        app = a["app"]
        for f in a["findings"]:
            if f.get("verdict") != "CONFIRME": continue
            fid = f["id"]; vid = fid  # fichiers nommés APPxx-Vyyy
            p = cap_path(app, fid.replace("APP-", "APP").replace("APP0", "APP0"))
            # nom réel du fichier = APP01-V001 (fid tel quel)
            p = os.path.join(BASE, "evidence", app, "captures", fid + ".http")
            if not os.path.exists(p):
                g = glob.glob(os.path.join(BASE, "evidence", app, "captures", "*%s.http" % vof(fid)))
                p = g[0] if g else None
            if not p:
                tot["MANQUANT"] += 1; suspects.append((fid, "MANQUANT", "aucun fichier de capture")); continue
            statuses, headers, body, raw = parse(p)
            verdict, note = classify(fid, f.get("title"), f.get("kind"), statuses, headers, body, raw)
            tot[verdict] += 1
            if verdict == "SUSPECT": suspects.append((fid, "SUSPECT", note))
            elif verdict == "REVIEW": reviews.append((fid, "REVIEW", note))
            elif SHOW_ALL: print("  OK      %-12s %s" % (fid, f.get("title", "")[:60]))

    print("\n===== SUSPECT (preuve probablement absente — à corriger) =====")
    for fid, v, note in suspects: print("  %-12s %s" % (fid, note))
    if not suspects: print("  (aucun)")
    print("\n===== REVIEW (vérification manuelle recommandée) =====")
    for fid, v, note in reviews: print("  %-12s %s" % (fid, note))
    if not reviews: print("  (aucun)")
    n = sum(tot.values())
    print("\n===== BILAN =====")
    print("  OK=%d  REVIEW=%d  SUSPECT=%d  MANQUANT=%d  (total=%d)" % (tot["OK"], tot["REVIEW"], tot["SUSPECT"], tot["MANQUANT"], n))
    print("  -> OK = preuve auto-vérifiée ; REVIEW = signal attendu non auto-détectable (normal pour SSRF/SQLi/désérialisation) ; SUSPECT = à corriger.")

if __name__ == "__main__":
    main()
